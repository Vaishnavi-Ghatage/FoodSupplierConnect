<?php include 'connect.php' ?>

<?php
$prid=$_POST['pid'];
$sql33="delete from `orders` where id='$prid'";
$res33=mysqli_query($con,$sql33);
if($res33){
    header("Location: order_history.php?prDel=true");
        exit();
}
else{
    echo "Error: " . mysqli_error($con);
}



?>
