<?php include 'connect.php' ?>
<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true){
  header("location:index.php");
  exit;
}
?>
<?php
// Check if item_deleted parameter is present in the URL
if(isset($_GET['logdin']) && $_GET['logdin'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
        <div class="success-symbol">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16" id="logddin">
        <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0z"/>
        <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708z"/>
    </svg>
    
        </div>
        <div class="success-message">Logged In Successfully!!</div>
    </div>
    ';
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      *{
        color:black;
        
      }
      
      h2{
        text-align:center;
        
      }
      .carousel-item img{
        padding: 8px;
      }
      .box:hover{
		transform: scale(1.1);
		z-index: 2;

	}
  .show-all{
    cursor: pointer;
  }
  .clickable{
            cursor: pointer;
        }
  .card{
    display : hidden;
  }
  .hidden-dishes{
    display:none;
  }
  .success-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }
    
        .success-symbol {
            font-size: 50px;
            color: green;
            margin-right: 10px;
        }
        #cartAdd{
          width:4rem;
          height:4rem;
          margin-left:35%;
        }
        #logddin{
          width:4rem;
          height:4rem;
          margin-left:30%;
        }
       .cuisine{
        font-size:40px;
        font-family: cursive;
       }
  .catName{
    font-family: fantasy;
  }
  .hr1{
            background-color: black; /* Dark background color */
    border-color: black; /* Dark border color */
    height: 2px;
        }
        .dull-product {
    opacity: 0.5; /* Reduce opacity to make it appear dull */
    /* Add any other styles to make the product appear dull */
}
        
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
</head>
<body>
  

<?php include 'nav6.php'  ?>
<?php include 'connect.php' ?>



<br>

<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="Menu\pic1.jpeg" class="d-block w-100" alt="..." style="height: 550px;">
    </div>
    <div class="carousel-item">
      <img src="Menu\pic2.jpeg" class="d-block w-100" alt="..." style="height: 550px;">
    </div>
    <div class="carousel-item">
      <img src="pic12.jpeg" class="d-block w-100" alt="..."  style="height: 550px;">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

    <div class="container mt-5" id="browse_cuisines">
      <h2 class="cuisine">Cuisine List</h2>
      <div class="c1">
        <div class="row">

            <?php
                
                $sql_cat="select distinct product_category from `Menu`";
                $res_cat=mysqli_query($con,$sql_cat);
                while($product_cat=mysqli_fetch_assoc($res_cat)){
                    $cat_name=$product_cat['product_category'];

                    echo "<h2 style='text-align:left; color:Maroon;' id='$cat_name' class='catName'>$cat_name<br></h2>";
                    
                    $sql= "select * from `Menu` ";
                $result = mysqli_query($con,$sql);
                if($result){
                   
                  
                    while ($row = mysqli_fetch_assoc($result)){
                        $id=$row['product_id'];
                        $name=$row['product_name'];
                        $desc=$row['product_desc'];
                        $price=$row['product_price'];
                        $quantity=$row['avail_q'];
                        $image=$row['product_image'];
                        $cat=$row['product_category'];
                        $supp=$row['product_supplier'];
                        if($cat===$cat_name && $cat=="Homemade"){

                         if($quantity==0){
                          $s="Not Available You can not place order right now";
                         }
                         else{
                          $s="You can Order upto " .$quantity." items.";
                         }
                        //  $productClass = ($quantity == 0) ? "dull-product" : "";
                        echo '<div class="col-md-4 col-sm-6 col-xm-12 mb-5 i1">
                        <div class="card">
                        
                            <img src='.$image.' class="card-img-top box" alt="product photo" style="height:300px; object-fit:contain" >
                            <div class="card-body">
                                <h5 class="card-title"><b>'.$name.'</b></h5>
                                <p class="card-text">'.substr($desc,0,65).'....</p>
                                <p ><b>'.$price.'/-</b></p>
                                <p>Available Quantity: <b>'.$quantity.'</b></p>
                                <p>'.$s.'</p>
                           
                                <a href="order.php?id='.$id.'&supp='.$supp.'" class="btn btn-primary">Order Now</a>
                                <button type="button" class="btn btn-primary" onclick="redirectTo('.$id.')">
                                
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-check" viewBox="0 0 16 16">
                            <path d="M11.354 6.354a.5.5 0 0 0-.708-.708L8 8.293 6.854 7.146a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0z"></path>
                            <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"></path>
                            </svg>
                                Add To Cart
                                </button>
                            </div>
                        </div>
                        </div>';
                          
                   
                  }
                  else if($cat===$cat_name){

                    if($quantity==0){
                     $s="Not Available You can not place order right now";
                    }
                   

                   echo '<div class="col-md-4 col-sm-6 col-xm-12 mb-5 i1">
                   <div class="card">
                   
                       <img src='.$image.' class="card-img-top box" alt="product photo" style="height:300px; object-fit:contain" >
                       <div class="card-body">
                           <h5 class="card-title"><b>'.$name.'</b></h5>
                           <p class="card-text">'.substr($desc,0,65).'....</p>
                           <p ><b>'.$price.'/-</b></p>
                           
                      
                           <a href="order.php?id='.$id.'&supp='.$supp.'" class="btn btn-primary">Order Now</a>
                           <button type="button" class="btn btn-primary" onclick="redirectTo('.$id.')">
                           
                           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-check" viewBox="0 0 16 16">
                       <path d="M11.354 6.354a.5.5 0 0 0-.708-.708L8 8.293 6.854 7.146a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0z"></path>
                       <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"></path>
                       </svg>
                           Add To Cart
                           </button>
                       </div>
                   </div>
                   </div>';
                     
              
             }
                  
                }
                echo '<hr class="hr1">';
               
               
                }
              }
              

?>

</div>
</div>
</div>



          






<?php
    if (isset($_GET['added_to_cart']) && $_GET['added_to_cart'] == 'true') {
      echo '
          <div class="success-container" id="success-container">
              <div class="success-symbol">
              <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="icon bi bi-cart-check" viewBox="0 0 25 25" id="cartAdd">
            <path d="M11.354 6.354a.5.5 0 0 0-.708-.708L8 8.293 6.854 7.146a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0z"/>
            <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
        </svg>
              </div>
              <div class="success-message">Item added to cart</div>
          </div>
      ';
  }
    ?>
<?php include 'about.php'  ?>
<?php 
// include 'footer.php'
  ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script>

// document.querySelector(".show-all").addEventListener("click", function() {
   
//     document.querySelector(".hidden-dishes").style.display = "block";
// });

function redirectTo(id){
var urll='addCart.php?id='+id;
 window.location.href=urll;
}

document.addEventListener("DOMContentLoaded", function() {
          
            var successContainer = document.getElementById("success-container");
            if (successContainer) {
                successContainer.style.display = "block";
                // Hide the success-container after 3 seconds
                setTimeout(function() {
                    successContainer.style.display = "none";
                }, 1000);
            }
        });
        document.querySelectorAll(".show-all").forEach(function(btn) {
        btn.addEventListener("click", function() {
            var category = this.getAttribute("data-category");
            document.querySelectorAll("[data-category='" + category + "']").forEach(function(card) {
                card.style.display = "block";
            });
            this.style.display = "none"; // Hide the "View more" button after clicking
        });
    });
 

</script>


</body>
</html>