<!-- <a href="home.php" class="nav-link px-2 link-secondary fs-5 link1"><p>Home</p></a> -->



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="about.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"/>
    <title>Our team</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bellota+Text:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap');
*
{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    /color:#111;/
    font-family: 'Bellota Text',cursive;
}
.container10{
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 1rem 8rem;
    padding: 20px 27px;
    box-shadow: 10px 10px 18px -8px #aaaaaa,-10px -10px 24px #ffffff;
    height: 500px;
    width: 750px;
}
.container10 img
{
    height: 100%;
    width: auto;
    border-radius: 20px;
    height: 600px;
    width: 60px;
}
.about_details{
    margin: 0 45px;

}
.about_details span{
    color: red;
}
.about_details h2{
    font-family: "Potta One";
    font-weight: 100;
    font-size: 26px;
    letter-spacing: 1px;
    margin-bottom: 20px;
}
.about_details p{
    color: gray;
    font-size: 15px;

}

body{
    display: block;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    width: 100%;
    background: #f2f3f7;
}
.container11
{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}
.container11 .card12
{
    width: 220px;
    height: 416px;
    padding: 60px 30px;
    margin: 20px;
    background: #f2f3f7;
    box-shadow: 0.6em 0.6em 1.2em #d2dce9,
                -0.5em -0.5em 1em #ffffff;
    border-radius: 20px;

}
.container11 .card12 .content13{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}
.container11 .card12 .content13 .imgBx
{
    width: 180px;
    height: 180px;
    border-radius: 50%;
    position: relative;
    margin-bottom: 20px;
    overflow: hidden;
}
.container11 .card12 .content13 .imgBx img
{
    position: absolute;
    top:0;
    left:0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.container11 .card12 .content13 .imgBx h4
{
    color: #36187d;
    font-size: 1.7rem;
    font-weight: bold;
    text-align: center;
    letter-spacing: 1px;
}
.container11 .card12 .content13 .imgBx h5
{
    color: #6c758f;
    font-size: 1.2rem;
    font-weight: bold;
    text-align: center;

}
.container11 .card12 .content13 .sci
{
    text-decoration: none;
}
.container11 .card12 .content13 .sci a
{
    text-decoration: none;
    color: #6c758f;
    font-size: 30px;
    margin: 10px;
    transition:color 0.4s;

}
.container11 .card12 .content13 .sci a:hover
{
    color: #0196e3;
}
.footer{
    position: fixed;
    bottom: 0px;
    width: 100%;
    /* background: #111; */
}
.main-content{
    display: flex;

}
.main-content .box{
    flex-basis: 50%;
    padding: 10px 20px;
}
.box h2{
    font-size: 1.125rem;
    font-weight: 600;
    text-transform: uppercase;
    color:white;

}
.box .content1{
    margin: 20px 0 0 0;
    /* color:white; */
}
.left .content1 p{
    text-align: justify;
    color:white;
}
.left .content1 .social{
    margin: 20px 0 0 0;
}
.left .content1 .social a{
    padding: 0 2px;
    color:white;
}
.left .content1 .social a i{
    height: 40px;
    width: 40px;
    background:white;
    line-height: 40px;
    text-align: center;
    font-size: none;
    border-radius: 5px;
    transform: 0.3s;
}
.left .content1 .social a i:hover{
    background:rgb(251, 237, 237);
}
/* .link1{
            margin-left:50px;
            margin-top:10px;
            
        } */
        .link1 p{
            font-size:22px;
            margin-left:50px;
            margin-top:10px;
            color:white;
        }
        .foot{
            background-color:black;
        }
        .text{
            color:white;
        }
    </style>
</head>
<body><center>
    <div class="container10">
        <!-- <img src="n3.jpg" alt="b"> -->
        <div class="about_details">
            <span><h1>About Our Website</h1></span>
            <h2>We Provide Good Quality Food To Your Family!</h2>
            <i><h3>order online we are always ready to fulfill your demand.we provide your order within a very short time.Keep with us to take our delicious food</h3></i>
            <br>
            <i><h3>"DELIGHT IN EVERY BITE."</h3></i>
        </div>
    </div>
</center>
            <div class="container11">

        <div class="card12">

            <div class="content13">
                <div class="imgBx">
                    <img src="Menu\about.jpeg" alt="jmg">

        </div>
        <div class="contentBx">
            <h4>The Empire</h4>
            <!-- <h5>Director gerenal</h5> -->
            </div>
            <div class="sci">
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>

                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>
    <div class="card12">
        <div class="content13">
            <div class="imgBx">
                <img src="Menu\about.jpeg" alt="jmg">

    </div>
    <div class="contentBx">
        <h4>The Krishna Palace</h4>
        <!-- <h5>The Krishna Palace</h5> -->
        </div>
        <div class="sci">
            <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>

            <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
        </div>
    </div>
</div>
<div class="card12">
        <div class="content13">
            <div class="imgBx">
                <img src="Menu\about.jpeg" alt="jmg">

    </div>
    <div class="contentBx">
        <h4>Annapurna Kitchen</h4>
        <!-- <h5>The Krishna Palace</h5> -->
        </div>
        <div class="sci">
            <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>

            <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
        </div>
    </div>
</div>
<div class="card12">
    <div class="content13">
        <div class="imgBx">
            <img src="Menu\about.jpeg" alt="jmg">

</div>
<div class="contentBx">
    <h4>The Coffee House</h4>
    <!-- <h5>Director gerenal</h5> -->
    </div>
    <div class="sci">
        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>

        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
    </div>
</div>
</div>

    </div>
    <div id="f">
    <footer class="foot">
        <div class="main-content">
         <div class="left box">
            <h2>About Us</h2>
            <div class="content1">
                <p>FOOD SUPPLIER CONNECT </p>
                <div class="social">
                    <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>

                        
                </div>
            </div>
         </div>
         <div class="center box">
            <h2>Phone</h2>
            <div class="content1">
                <div class="phone">
                   <a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a>
                    <i class="text">+091-9353746455</i>
                </div>
                <div class="phone">
                   <a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a>
                    <i class="text">+091-8147012842</i>
                </div>
                <div class="phone">
                    <a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a>
                    <i class="text">+091-8050255540</i>
                 </div>
            </div>
         </div>
         <div class="right box">
            <h2>Email</h2>
            <div class="content1">
                <div class="email">
                    <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                    <i class="text">sanikakulkarni28@gmail.com</i>
                 </div>  
                 <div class="email">
                    <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                    <i class="text">vaishnavighatage3523@gmail.com</i>
                 </div>  
                 <div class="email">
                    <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                    <i class="text">rutujakinange13@gmail.com</i>
                 </div>  
            </div>
         </div>
        </div>
    </footer>
    </div>
</body>
</html>