<?php include 'connect.php' ?>
<?php
// Check if item_deleted parameter is present in the URL
if(isset($_GET['add']) && $_GET['add'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
        <div class="success-message">Supplier Added Succesfully!!</div>
    </div>
    ';
}
?>

<?php
if(isset($_GET['deleted']) && $_GET['deleted'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
        <div class="success-symbol">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16" id="deleted">
                    <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                </svg>
        </div>
        <div class="success-message">Removed Supplier Succesfully!!</div>
    </div>
    ';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        
        html,body{
            height:100%;
            margin:0;
            padding:0;
            /* background-color:#f5efeB; */
        }
        .cont{
            min-height:75%;
            background-color:BEIGE;
        }
        .row{
           padding-left:30px;
           padding-right:30px;
           
        }
        .a1{
            border:1px solid black;
            height:150px;
        }
        h2{
            text-align:center;
        }
        .clickable{
            cursor: pointer;
            /* background-color:beige; */
           
        }
        .hidden{
            display:none;
        }
        .item{
            text-align:center;
            display:flex;
            align-items:center;
            justify-content:center;
            background-color:white;
            /* box-shadow: 0.6em 0.6em 1.2em #d2dce9,
                -0.5em -0.5em 1em #ffffff;
                background-color:#f3f4f8;
            */
        }
        .success-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }
    
        .success-symbol {
            font-size: 50px;
            color: green;
            margin-right: 10px;
        }
        #deleted{
            width:4rem;
            height:4rem;
            margin-left:35%;
        }
        #supp{
            width:3rem;
            height:3rem;
        }
        .a1 svg {
    display: block; /* Make the SVG display as block to ensure it takes up full width */
    margin: 0 ; /* Center the SVG horizontally */
}
.cent{
            border:solid black 1px;
            margin-left:200px;
            margin-right:200px;
            margin-top:15px;
            text-align:center;
            align-content:center;
            background-color:white;
        }
        .hr{
            background-color: grey; 
    /* border-color: grey;  */
    height: 2px;
        }
        .t1{
            border:2px solid black;
        }
        .col{
            background-color:white;
        }
        .cl{
            background-color:white;
        }
        .link2{
            margin-left:35px;
            margin-top:7px;
            
        }
        .link2 p{
            font-size:22px;
        }
        
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<?php echo '<a href="adminLogout.php" class="nav-link px-2 link-secondary fs-5 link2">Logout</a>';  ?>
<h3 style="text-align:center;font-size:26px;">Admin Page</h3>
<hr class="hr">

<div class="cont">
<h2 style="text-align:center;font-family: serif;font-size:38px;">DashBoard</h2>
<br>
<div class="row">
    <div class="col-md-4 col-sm-6 col-xm-12 mb-5 clickable" id="toggleDiv1">
        <div class="a1 item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill-check" viewBox="0 0 16 16" id="supp">
  <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
  <path d="M2 13c0 1 1 1 1 1h5.256A4.5 4.5 0 0 1 8 12.5a4.5 4.5 0 0 1 1.544-3.393Q8.844 9.002 8 9c-5 0-6 3-6 4"/>
</svg>

Suppliers
</div>
    </div>
    <div class="col-md-4 col-sm-6 col-xm-12 mb-5 clickable" id="toggleDiv2">
        <div class="a1 clickable item">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" id="supp">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
</svg>
<span style="margin-left:5px;"> Viewers</span></div>
    </div>
    <div class="col-md-4 col-sm-6 col-xm-12 mb-5 clickable" id="toggleDiv3">
        <div class="a1 clickable item"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16" id="supp">
  <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
</svg>
Orders</div>
    </div>
    </div>

       
    
    <section id="hiddenSection1" class="hidden">

    

            <div class="container">
                <h2>Suppliers</h2>
                <div class="cent" >
                   
                <?php
                $sql8="select count(*) as del from `admin`";
        $result8 = mysqli_query($con,$sql8);

        if($result8->num_rows>0){
            $row=$result8->fetch_assoc();
            echo "<p style='margin-top:7px; margin-bottom:1px;'>Total Suppliers: ".($row["del"]-1)."</p>";
        }
        else{
            echo "0 results";
        }
        ?>
        <br>
        </div>
            <button class="btn btn-primary my-5 mb-4 mx-auto float-left"  onclick="redirect('addSupp.php')">Add Supplier</button>
       
            <div class="mb-4 pl-4">
            <table class="table table-hover table-bordered t1">       
  <thead class="cl">
    <tr>
      <th scope="col">Supplier id</th>
      <th scope="col">Supplier name</th>
      <th scope="col" class="w-col">Operations</th>
    </tr>
  </thead>
  <tbody>
<?php
include 'connect.php';
// session_start();
//     $admin = $_SESSION['AdminID'];
   
$sql = "select * from `admin`";
$result = mysqli_query($con,$sql);
if($result){
    while($row=mysqli_fetch_assoc($result)){
        $id=$row['count'];
        $name=$row['adminID'];
        if($name!=='Admin'){
        echo '<tr>
                <th scope="row">'.$id.'</th>
                <td>'.$name.'</td>
                <td class="w-col">
                <button><a href="removeSupp.php?deleteid='.$id.'" class="btn btn-primary">Remove Supplier</a></button>
                <button><a href="showSupp.php?showname='.$name.'" class="btn btn-primary">Show Details</a></button>
                

                </td>
            </tr>
        ';
    }  
}
}
?>
  </tbody>
</table>
</div>
        </div>
    </section>



    <section id="hiddenSection2" class="hidden">
    <div class="container">
    <h2>Viewers</h2>
        <div class="cent">
        <?php
    $sql6 = "select count(*) as total_viewers from `signin`";
        $result6 = mysqli_query($con,$sql6);
        // echo "$result6";
        if($result6->num_rows>0){
            $row=$result6->fetch_assoc();
            echo "<p style='margin-top:7px; margin-bottom:7px;'>Total Viewers: ".$row["total_viewers"]."</p>";
        }
        else{
            echo "0 results";
        }
        ?>
        </div>
           
            <div class="mb-4 pl-4 mt-4">
            <table class="table table-hover table-bordered">       
  <thead>
    <tr>
      <th scope="col">User ID</th>
      <th scope="col">UserName</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <tbody>
<?php
include 'connect.php';
// session_start();
//     $admin = $_SESSION['AdminID'];
   
$sql = "select * from `signin`";
$result = mysqli_query($con,$sql);
if($result){
    while($row=mysqli_fetch_assoc($result)){
        $id=$row['id'];
        $name=$row['username'];
        $email=$row['email'];
        if($name!=='Admin'){
        echo '<tr>
                <th scope="row">'.$id.'</th>
                <td>'.$name.'</td>
                <td>'.$email.'</td>
                
            </tr>
        ';
    }  
}
}
?>
  </tbody>
</table>
</div>
        </div>
    </section>







    <section id="hiddenSection3" class="hidden">
        <h2>Orders Dashboard</h2>
        <div class="cent">
        <?php
        $sql6 = "select count(*) as total_count from `orders`";
        $result6 = mysqli_query($con,$sql6);
        // echo "$result6";
        if($result6->num_rows>0){
            $row=$result6->fetch_assoc();
            echo "Total Orders: ".$row["total_count"];
        }
        else{
            echo "0 results";
        }
       
        echo "<br>";
        echo "<br>";

        $sql7="select sum(total) as total_sales from `orders`";
        $result7 = mysqli_query($con,$sql7);
        // echo "$result6";
        if($result7->num_rows>0){
            $row=$result7->fetch_assoc();
            echo "Total Sales: ₹ ".$row["total_sales"];
        }
        else{
            echo "0 results";
        }

        echo "<br>";
        echo "<br>";

        $profit = 0;
$sql = "SELECT total FROM `orders`";
$res = mysqli_query($con, $sql);

if ($res->num_rows > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        $profit += ($row['total'] * 8) / 100; // Calculating 7% profit for each total
    }
}

echo "Total Profit Earned: ₹ " . $profit;

        echo "<br>";
        echo "<br>";







        $sql8="select count(*) as del from `orders` where status='Delivered'";
        $result8 = mysqli_query($con,$sql8);
        // echo "$result6";
        if($result8->num_rows>0){
            $row=$result8->fetch_assoc();
            echo "Delivered: ".$row["del"];
        }
        else{
            echo "0 results";
        }
        echo "<br>";
        echo "<br>";

        $sql8="select count(*) as dell from `cart`";
        $result8 = mysqli_query($con,$sql8);
        // echo "$result6";
        if($result8->num_rows>0){
            $row=$result8->fetch_assoc();
            echo "In cart: ".$row["dell"];
        }
        else{
            echo "0 results";
        }
?>
 </div>
            <div class="container">
           
       <!-- <p>Vish</p> -->
            <div class="mb-4 pl-4 mt-4">
            <table class="table table-hover table-bordered ">
  
        
  <thead>
    <tr>
    
      <th scope="col">product_name</th>
      <th scope="col">product_quantity</th>
      <th scope="col">Total Price</th>
      <th scope="col">Order Date & Time</th>
      <th scope="col">Status</th>
      <th scope="col">Suppier</th>
      <th scope="col">Customer Name</th>
      <th scope="col">Customer contact</th>
      <th scope="col">Customer Email</th>
      <th scope="col">Customer Address</th>

    </tr>
  </thead>
  <tbody>
<?php
include 'connect.php';

   
    $sql = "select * from `orders`";
    $result = mysqli_query($con,$sql);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
            $product_name=$row['food'];
            $quantity=$row['quantity'];
            $total=$row['total'];
            $Order_Time=$row['dateTime'];
            $status=$row['status'];
            $supp=$row['product_supplier'];
            $Customer_name=$row['cust_name'];
            $Customer_contact=$row['cust_contact'];
            $Customer_email=$row['cust_email'];
            $Customer_address=$row['cust_address'];
            echo '<tr>
                    <th scope="row">'.$product_name.'</th>
                    <td>'.$quantity.'</td>
                    <td>'.$total.'</td>
                    <td>'.$Order_Time.'</td>
                    <td>'.$status.'</td>
                    <td>'.$supp.'</td>
                    <td>'.$Customer_name.'</td>
                    <td>'.$Customer_contact.'</td>
                    <td>'.$Customer_email.'</td>
                    <td>'.$Customer_address.'</td>
                    
                </tr>
            ';
        }  
    }
?>
  </tbody>
</table>
</div>
        </div>
    </section>









    </div>
    <?php include 'footer.php'  ?>
    <script>
        function redirect(url){
            window.location.href=url;
        }

        document.getElementById('toggleDiv1').addEventListener('click',function(){
            var section=document.getElementById('hiddenSection1');
            if(section.classList.contains('hidden')){
                section.classList.remove('hidden');
            }
            else{
                section.classList.add('hidden');
            }
        });

        document.getElementById('toggleDiv2').addEventListener('click',function(){
            var section=document.getElementById('hiddenSection2');
            if(section.classList.contains('hidden')){
                section.classList.remove('hidden');
            }
            else{
                section.classList.add('hidden');
            }
        });

        document.getElementById('toggleDiv3').addEventListener('click',function(){
            var section=document.getElementById('hiddenSection3');
            if(section.classList.contains('hidden')){
                section.classList.remove('hidden');
            }
            else{
                section.classList.add('hidden');
            }
        });

        document.addEventListener("DOMContentLoaded", function() {
            // Check if the success-container should be displayed
            var successContainer = document.getElementById("success-container");
            if (successContainer) {
                successContainer.style.display = "block";
                // Hide the success-container after 3 seconds
                setTimeout(function() {
                    successContainer.style.display = "none";
                }, 1500);
            }
        });
    </script>
   
</body>
</html>