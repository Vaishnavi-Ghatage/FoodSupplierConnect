<?php
$success=0;
$user=0;
$pass=0;
$empt=0;
$invalid=0;
if($_SERVER['REQUEST_METHOD']=='POST'){
     include 'connect.php';

 
    $suppId=$_POST['suppId'];
    $password=$_POST['password'];
    $info=$_POST['info'];

    if(empty($suppId)){
        $empt=1;
    }
    else if(empty($password)){
        $empt=1;
    }
    else if(empty($info)){
        $empt=1;
    }
    else{

    $sql = "select * from `admin` where adminID='$suppId'";
    $result = mysqli_query($con,$sql);

    if($result){
        $num = mysqli_num_rows($result);
        if($num>0){
            // echo "user already exist";
            $user=1;
        }
        else{
           
            $sql="insert into `admin` (adminID,password,information) values('$suppId','$password','$info')";
            $result = mysqli_query($con,$sql);
            if($result){
                $success=1;
                echo '<script>window.location.href="Admin.php?add=true";</script>';
               
            }
            else{
                echo '<script>alert("Error:Something Went wrong");</script>';
                echo '<script>setTimeout(function(){window.location.href="Adminpage.php";},500);</script>';
            }
            
        }
       
        }
    } 
}

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Supplier</title>
    <style>
             *{
    box-sizing: border-box;   
    padding: 0;   
    
}
.container{
    margin-top: 20px;
    align-items: center;
    max-width: 600px;
    margin: auto;
    width: 90%;
    /* height:80%; */
    /* padding-bottom:10px; */
    border-radius: 10px;
    margin-bottom: 10px; 
    /* margin-left:40%; */
}
label,input{
    display: block;
    margin-top: 5px;
    min-width: 100%;   
}
form{   
    max-width: 600px;
    width: 90%;
    margin: auto;
    margin-top: 2rem;
    margin-bottom: 5rem;   
}
input{
    min-width: 100%;
    min-height: 5vh;
    border: 1px solid black;
    padding: 0.5rem;
    border-radius: 5px;
    height: 1rem;
}
label{
    font-weight: bolder;
    margin-top: 1rem;
}
 .cc{
    background-color:#D3D3D3;  
    padding-left:40px;
    padding-right:40px;
    border-radius:10px;
 }

.bttn{
    max-width: 300px;
    width: 100px;
    align-items: center;
    background-color: grey;
    color: white;
    font-weight: bold;
    border-radius: 5px;
    padding: 5px;
    align-self: center;
    font-weight: bold;
    margin-top:6px;
   
}
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<a href="Admin.php" class="nav-link px-2 link-secondary fs-5 link1"><p>Back</p></a>
<?php
        if($empt){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Please</strong> Fill the form Completely!!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
        <?php
        if($user){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Ohh No!</strong> Supplier Already Exist.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
       <?php
        if($success){
             echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
             Supplier added successfully!!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>



<h2 style="font-size:25px; color:maroon; margin-left:40%; margin-top:20px;"><b>Add Supplier Here</b></h2>
    <div class="container">
        <form action="addSupp.php" name="addSupp" method="post" class="cc mt-5">
            <label for="suppid">Supplier ID</label>
            <input type="text" id="suppId" name="suppId" autocomplete="off">
            <div>
            <label for="password">Supplier password</label>
            
        <input type="password" name="password" id="password" placeholder="Enter Password" autocomplete='off'>
        <img src="eye-off-icon.svg" width="23px" height="23px" 
        style="position: absolute; right: 30%; top: 45%; transform: translateY(-90%);" id="togglePassword1">
        </div>
        <label for="info">Information About Supplier</label>
        <input type="text" id="info" name="info" autocomplete="off">
            <input type="submit" value="Add" name="submit" class="bttn mb-4 mt-2" id="submitBtn">
        </form>
    </div>
    <script>
        const togglePassword1 =  document.querySelector('#togglePassword1');
const password1 = document.querySelector('#password');
togglePassword1.addEventListener('click', function (e) {
const type = password1.getAttribute('type') === 'password' ? 'text' : 'password';
password1.setAttribute('type', type);
 if (togglePassword1.src.match("eye-off-icon.svg")) {
        togglePassword1.src ="eye-icon.svg";
    } 
    else {
         togglePassword1.src ="eye-off-icon.svg";
     }
}); 



    </script>
</body>
</html>