<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="sign.css">
</head>
<body>
<?php include 'nav2.php'  ?>
<?php include 'connect.php' ?>
    <div class="container">
        <form action="signin.php" method="POST">
        <div>
        <label for="username">Username:</label>
        <input type="text/email"  name="username" id="username" placeholder="Enter Username/Email">
        </div>
        <div>
        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Enter Password">
        </div>
        <div>
            <input type="submit" value="SignIn" class="btn">
        </div>
        </form>
    </div>
</body>
</html>