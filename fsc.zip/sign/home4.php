<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      *{
        color:black;
      }
      h2{
        text-align:center;
        
      }
      .carousel-item img{
        padding: 5px;
      }
      .box:hover{
		transform: scale(1.1);
		z-index: 2;
    border:2px solid black;
    
	}
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
</head>
<body>
    
<?php include 'nav5.php'  ?>
<?php include 'connect.php' ?>

<br>

<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="pic1.jpg" class="d-block w-100" alt="..." style="height: 550px;">
    </div>
    <div class="carousel-item">
      <img src="pic2.jpg" class="d-block w-100" alt="..." style="height: 550px;">
    </div>
    <div class="carousel-item">
      <img src="pic3.jpg" class="d-block w-100" alt="..."  style="height: 550px;">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
 
    <div class="container mt-5" id="browse_cuisines">
      <h2>Cuisine List</h2>
        <div class="row">

            <?php
                
                // $sql= "select * from `Menu` ";
                // $result = mysqli_query($con,$sql);
                // if($result){
                    // $row = mysqli_fetch_assoc($result);
                    // echo $row['category_name'];

                //     while ($row = mysqli_fetch_assoc($result)){
                //         $id=$row['product_id'];
                //         $name=$row['product_name'];
                //         $desc=$row['product_desc'];
                //         $price=$row['product_price'];
                //         $image=$row['product_image'];


                //         echo '<div class="col-md-4 col-sm-6 col-xm-12 mb-5">
                //         <div class="card box">
                //             <img src='.$image.' class="card-img-top" alt="product photo" style="height:300px; object-fit:contain" >
                //             <div class="card-body">
                //                 <h5 class="card-title">'.$name.'</h5>
                //                 <p class="card-text">'.substr($desc,0,65).'....</p>
                //                 <p>'.$price.'/-</p>
                //                 <a href="details.php?id='.$id.'" class="btn btn-primary">Shop Now</a>
                //             </div>
                //         </div>
                //         </div>';
                //     }
                // }
                $sql_cat="select distinct product_category from `Menu`";
                $res_cat=mysqli_query($con,$sql_cat);
                while($product_cat=mysqli_fetch_assoc($res_cat)){
                    $cat_name=$product_cat['product_category'];

                    echo "<h2 style='text-align:left;' id='$cat_name'>$cat_name<br></h2>";
                    
                    $sql= "select * from `Menu` ";
                $result = mysqli_query($con,$sql);
                if($result){
                   
                  $count=1;
                    while ($row = mysqli_fetch_assoc($result)){
                        $id=$row['product_id'];
                        $name=$row['product_name'];
                        $desc=$row['product_desc'];
                        $price=$row['product_price'];
                        $image=$row['product_image'];
                        $cat=$row['product_category'];
                        if($cat===$cat_name){

                          if($count<=5){

                        echo '<div class="col-md-4 col-sm-6 col-xm-12 mb-5">
                        <div class="card box">
                            <img src='.$image.' class="card-img-top" alt="product photo" style="height:300px; object-fit:contain" >
                            <div class="card-body">
                                <h5 class="card-title">'.$name.'</h5>
                                <p class="card-text">'.substr($desc,0,65).'....</p>
                                <p>'.$price.'/-</p>
                                <a href="details.php?id='.$id.'" class="btn btn-primary">Shop Now</a>
                            </div>
                        </div>
                        </div>';
                          
                    }
                    $count=$count+=1;
                  }
                }
                if($count>5){
                  echo '<div class="col-md-4 col-sm-6 col-xm-12 mb-5 ">
                          <div class="card box h-100 btn btn-primary show-all clickable" >
                              View more...
                          </div>
                          </div>'; 
                    
                }
              }
            }
?>



</body>
</html>

<?php include 'footer.php'  ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>
</html>