<?php
 include 'connect.php';

 if(isset($_SESSION['update'])){
    echo $_SESSION['update'];
    unset($_SESSION['update']);
 }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
         *{
    box-sizing: border-box;   
    padding: 0;   
}
.container{
    margin-top: 10px;
    align-items: center;
    max-width: 600px;
    margin: auto;
    width: 90%;
    background-color:beige;  
    border-radius: 10px;
    margin-bottom: 10px; 
}
label,input{
    display: block;
    margin-top: 5px;
    min-width: 100%;   
}
form{   
    max-width: 500px;
    width: 90%;
    margin: auto;
    margin-top: 1rem;
    margin-bottom: 5rem;  
    background-color:beige;  
}
input{
    min-width: 100%;
    min-height: 5vh;
    border: 1px solid black;
    padding: 0.5rem;
    border-radius: 5px;
    height: 1rem;
}
label{
    font-weight: bolder;
    margin-top: 1rem;
}
 

.bttn{
    max-width: 300px;
    width: 100px;
    align-items: center;
    margin-top:8px;
    color: white;
    font-weight: bold;
    border-radius: 5px;
    padding: 5px;
    align-self: center;
    font-weight: bold;
    color:white;
    background-color:grey;
}
h2{
    text-align:center;
}
.file-input-wrapper{
    position:relative;
    overflow:hidden;
    display:inline-block;
    border:1px solid #ccc;
    border-radius:4px;
    padding:6px 12px;
    cursor:pointer;
    width:150px;
}
.file-input-wrapper input[type=file]{
    position : absolute;
    font-size:100px;
    opacity: 0;
    right:0;
    top:0;
    cursor:pointer;
}
.file-path{
    margin-left:2px;
    width:250px;
    box-sizing:border-box;
}input[type="submit"]{
            height:35px;
        }
        .btn{
    
    font-weight: bold;
    background-color:grey; 
    color:white;
    
}
.btn:hover{
    background-color:grey; 
    border:1px solid black;
    color:white;
}
.link1{
            margin-left:35px;
            margin-top:7px;
            
        }
        .link1 p{
            font-size:22px;
        }
    </style>
</head>
<body>
<ul class="nav col-12 col-md-auto mb-2 justify-content-left mb-md-0">
        <li><a href="Adminpage.php" class="nav-link px-2 link-secondary fs-5 link1"><p>Back</p></a></li> 
</ul>
    <div class="container mt-2">
    <h2>Edit Product</h2>

    <?php
 
//   $id=isset($_GET['editid']);
if(isset($_GET['editid'])){
    $id=$_GET['editid'];

    $sql1="select * from `menu` where product_id=$id";
    
    $res=mysqli_query($con,$sql1);
    if($res){
        $count = mysqli_num_rows($res);
        if($count==1){
            $row=mysqli_fetch_assoc($res);
            
            $product_name=$row['product_name'];
            $product_desc=$row['product_desc'];
            $product_price=$row['product_price'];
            $product_image=$row['product_image'];
        }
        else{
            header('location:Adminpage.php');
        }
    }
    
}
     
             
    
    




?>

       
        <form action="" method="POST" id="addMenu">
            <!-- <input type="hidden" id="productId" name="productId"> -->
            <label for="name">Product name :</label>
            <input type="text" name="name" id="name" autocomplete="off" value="<?php echo "$product_name"; ?>">
            <label for="desc">Product desc :</label>
            <input type="text" name="desc" id="desc" autocomplete="off" value="<?php echo "$product_desc"; ?>">
            <label for="price">Product price :</label>
            <input type="number" name="price" id="price" autocomplete="off" value="<?php echo $product_price; ?>">

            <label for="image"> Product image :</label>
        <div class="file-input-wrapper">
        <input type="file" id="image" name="image" accept="image/*">
        <span  class="btn">Browse</span>
        </div>
        <input type="text" id="imagePath" name="imagePath" class="file-path" value="<?php echo "$product_image"; ?>" readonly>
            <!-- <button type="submit" class="bttn" name="submit">Update</button> -->


            <!-- <label for="image"> Product image :</label>
        <div class="file-input-wrapper">
        <input type="file" id="imageInput" name="image" accept="image/*">
        <span>Browse</span>
        </div>
        <input type="text" id="imagePath" class="file-path" readonly> -->



            <input type="hidden" id="id" name="id" value="<?php echo $id ?>">
            <input type="submit" name="submit" value="update" class="btn mb-3 mt-3">
        </form>
    </div>
<?php
 if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $name=$_POST['name'];
    $desc=$_POST['desc'];
    $price=$_POST['price'];
    $image=$_POST['image'];

    $sql = "update `menu` set product_name='$name',product_desc='$desc',product_price='$price',product_image='$image' where product_id='$id' ";

    $res = mysqli_query($con,$sql);
    if($res){
      
        echo '<script>window.location.href="Adminpage.php?updated=true";</script>';
    }
    else{
        echo '<script>alert("Update Failed");</script>';
        echo '<script>setTimeout(function(){window.location.href="Adminpage.php";},500);</script>';
    }
}

?>


       
        <script>
        document.getElementById('image').addEventListener('change',function(){
            const file = this.files[0];
            if (file){
                const fileName = file.name;
                document.getElementById('imagePath').value=fileName;
            }
        });
    </script>

</body>
</html>