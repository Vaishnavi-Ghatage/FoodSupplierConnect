<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
     include 'connect.php';

    session_start();
    $admin = $_SESSION['AdminID'];

     $product_name=$_POST['name'];
     $product_desc=$_POST['desc'];
     $product_price=$_POST['price'];
     $product_image=$_POST['image'];
     $product_category=$_POST['cat'];

    if(empty($product_name)||empty($product_desc)||empty($product_price)||empty($product_image)){
        echo '<script>alert("Error:Something Went wrong");</script>';
        echo '<script>setTimeout(function(){window.location.href="Adminpage.php";},500);</script>';
        exit("error");
    }

     $sql="insert into `Menu` (product_name,product_desc,product_price,product_image,product_supplier,product_category) values('$product_name','$product_desc','$product_price','$product_image','$admin','$product_category')";

     $result = mysqli_query($con,$sql);

     if($result){
        echo '<script>alert("Product Added Successfully");</script>';
        echo '<script>setTimeout(function(){window.location.href="Adminpage.php";},500);</script>';
        // header('location:Adminpage.php');
    }
    else{
        echo '<script>alert("Error:Something Went wrong");</script>';
        echo '<script>setTimeout(function(){window.location.href="Adminpage.php";},500);</script>';
    }
  
}
?>

<?php include 'connect.php' ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       li{
            margin-top:10px;
            list-style-type: none;
            
        }
        .link1{
            float:left;
            font-size:20px;
        
        }
        .card{
            margin-left:25px;
            display:flex;
            /* justify-co
             */
             gap:40px;
             
        }
        label,input{
            display:block;
            

        }
        form label{
            font-size:1.2rem;
            margin-left:25px;
            margin-bottom:8px;

        }
        form input{
            width:500px;
            margin-left:25px;
            margin-bottom:8px;
        }
        input{
            border:1px solid black;
            height:25px;
        }
    </style>
</head>
<body>
<ul class="nav col-12 col-md-auto mb-2 justify-content-around mb-md-0">
        <li><a href="home.php" class="nav-link px-2 link-secondary fs-5 link1">Home</a></li>
</ul>
    </br>
    <h2>Fill this form to confirm your order</h2>
    <div class="cont1">
        
<h2>Selected Food</h2>
    <?php

if(isset($_GET['id'])){
    $id=$_GET['id'];

    $sql= "select * from `Menu` where product_id=$id";
    
    $res=mysqli_query($con,$sql);
    if($res){
        $count = mysqli_num_rows($res);
        if($count==1){
            $row=mysqli_fetch_assoc($res);
            
            $name=$row['product_name'];
            $price=$row['product_price'];
            $image=$row['product_image'];

            echo '<div mb-5">
<div class="card box">
    <div><img src='.$image.' class="card-img-top" alt="product photo" style="height:200px; object-fit:contain" ></div>
    <div class="card-body">
        <h2 class="card-title">'.$name.'</h2>
        <p style="font-size:20px;">'.$price.'/-</p>
        <label style="font-size:20px;">Quantity</label><br>
        <input type="number" name="quantity" class="input-responsive" value="1" required>
        
    </div>
</div>
</div>';
        }
        
    }
    
}


?>

<h2>Delivery Details</h2>
    <form action="order.php" method="post">
        <label for="name">Full Name</label>
        <input type="text" name="name">
        <label for="number">Phone Number</label>
        <input type="number" name="number">
        <label for="email">Email</label>
        <input type="email" name="email">
        <label for="address">Address</label>
        <input name="address">
        <input type="submit" value="Confirm Order" name="submit">

    </form>

    </div>
</body>
</html>