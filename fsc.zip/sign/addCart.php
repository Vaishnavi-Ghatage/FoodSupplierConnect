<?php include 'connect.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .success-container {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    /* background-color: rgba(255, 255, 255, 0.9); */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    z-index: 9999;
  }
  
  .success-symbol {
    font-size: 50px;
    color: green;
    margin-right: 10px;
  }

    </style>
</head>
<body>
    
<?php 


    



session_start();
if (isset($_SESSION['username1']) || isset($_SESSION['username2'])) {
    if (isset($_SESSION['username1'])) {
        $un = $_SESSION['username1'];
    } else {
        $un = $_SESSION['username2'];
    }

    $sql9 = "select email from `signin` where username='$un'";
    $res9 = mysqli_query($con, $sql9);
    $row9 = mysqli_fetch_assoc($res9);
    $email = $row9['email'];

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql8 = "select product_name,product_price,product_image,product_supplier from `menu` where product_id='$id'";
        $result8 = mysqli_query($con, $sql8);
        if ($result8) {
            while ($row = mysqli_fetch_assoc($result8)) {
                $product_name = $row['product_name'];
                $product_price = $row['product_price'];
                $product_image = $row['product_image'];
                $product_supplier = $row['product_supplier'];
            }

            $sql = "insert into `cart` (product_name,product_price,product_image,product_supplier,cust_name,cust_email) values('$product_name','$product_price','$product_image','$product_supplier','$un','$email')";
            $result = mysqli_query($con, $sql);
            if ($result) {
                header('location:home.php?added_to_cart=true');
                exit();
            }
        }
    }
}
?>













</body>
</html>


