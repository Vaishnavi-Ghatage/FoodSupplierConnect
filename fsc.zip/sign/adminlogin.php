<?php
$success=0;
$pass=0;
$empt=0;
$invalid=0;
if($_SERVER['REQUEST_METHOD']=='POST'){
     include 'connect.php';
    //  $sql="insert into `adminsignin` (AdminID,password,confirm) values('$AdminID','$password','$confirm')";
    //  $result = mysqli_query($con,$sql); 
     if(isset($_POST['admin-submit'])){
        $AdminID=$_POST['AdminID'];
        $password=($_POST['password']);
        $confirm=$_POST['confirm'];
        if(empty($AdminID)){
            $empt=1;
        }
        else if($password===$confirm){
        $sql = "select * from `admin` where AdminID='$AdminID' AND password='$password'";
        $result = mysqli_query($con,$sql);
        if($result){
            $num = mysqli_num_rows($result);
            if($num>0){
                // echo "user already exist";
                $success=1;
                session_start();
                if($AdminID=='Admin'){
                    header('location:Admin.php');
                }else{
                    $_SESSION['AdminID']=$AdminID;
                    header('location:Adminpage.php?logdin=true');
                }
                    
            }
            else{
                $invalid=1;
            }    
            }
        } 
        else{
            $pass=1;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<style>
    /* *{
    box-sizing: border-box;   
    padding: 0;   
} */
body {
    position: relative;
}

*::before {
    box-sizing: border-box;   
    padding: 0;
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%; 
    background-image: url('b7.jpeg');
   background-size: cover;
    background-repeat: no-repeat;
    filter: blur(1px);  
    z-index: -1;
}
.container{
    margin-top: 30px;
    align-items: center;
    max-width: 600px;
    margin: auto;
    width: 90%;
    /* background-color: rgb(238, 189, 133); */
    border-radius: 10px;
    margin-bottom: 10px; 
    margin-left:20%;
    border:1px solid black;
}
label,input{
    display: block;
    margin-top: 5px;
    min-width: 100%;   
}
form{   
    max-width: 500px;
    width: 90%;
    margin: auto;
    margin-top: 2rem;
    margin-bottom: 2rem;   
}
.sign input{
    min-width: 100%;
    min-height: 5vh;
    border: 1px solid black;
    padding: 0.5rem;
    border-radius: 5px;
    height: 1rem;
}
label{
    font-weight: bolder;
    margin-top: 1rem;
}
.btn{
    background-color: #F7E7CE;
    /* color: white; */
    font-weight: bold;
}
.btn:hover{
    background-color: #F7E7CE;
    border:1px solid black;
}
h2{
    text-align:center;
    font-size:2rem;
}
input[type="submit"]{
    margin-top:5px;
            height:35px;
        }
        #contact{
            margin-left:250px;
        }
</style>
<body>
<?php
        if($empt){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Please</strong> Enter ID and password!!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
       <?php
        if($success){
             echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
             <strong>Admin </strong> Logid-IN succesfully!!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
<?php
        if($pass){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
             <strong>Ohh No!</strong>Password did not match!!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
<?php
        if($invalid){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error! </strong> Invalid Credentials.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
    <div class="container mt-5">
        <h2>Admin LogIn</h2>
<form method="POST" class="signup-form sign">
        <div>
            <label for="Admin-name">AdminID :</label>
        <input type="text"  name="AdminID" id="AdminID" placeholder="Enter AdminID" autocomplete='off'>
        </div>



        <!-- <div>
            <label for="password">Password :</label>
        <input type="password" name="password" id="password" placeholder="Enter Password" autocomplete='off'>
        <img src="eye-off-icon.svg" width="4%" height="4%" 
                style=
                 "display: inline;   margin-left: 470px; margin-top:-10.5%;
                    vertical-align: middle" id="togglePassword1">
        </div> -->
        <!-- <div><label for="confirm">Confirm Password :</label>
            <input type="password" name="confirm" id="confirm" placeholder="Enter password again" autocomplete='off'>  
            <img src="eye-off-icon.svg" width="4%" height="4%" 
                style=
                 "display: inline;   margin-left: 470px; margin-top:-10.5%;
                    vertical-align: middle" id="togglePassword2">
            <br> 
            </div>   -->
            

            <div style="position: relative;">
    <label for="password">Password :</label>
    <input type="password" name="password" id="password" placeholder="Enter Password" autocomplete='off'>
    <img src="eye-off-icon.svg" width="23px" height="23px" 
        style="position: absolute; right: 5px; top: 90%; transform: translateY(-90%);" id="togglePassword1">
</div>

        <div style="position: relative;">
    <label for="confirm">Confirm Password :</label>
    <input type="password" name="confirm" id="confirm" placeholder="Enter Password again" autocomplete='off'>
    <img src="eye-off-icon.svg" width="23px" height="23px" 
        style="position: absolute; right: 5px; top: 90%; transform: translateY(-90%);" id="togglePassword2">
</div>
            








        <div>
            <input type="submit" value="submit" class="btn mt-2" name="admin-submit">
        </div>      
 </form>
 </div>

 <p id="contact">Want To Be A Supplier? <a href="about.php#f">Contact</a></p>


 <script>
    const togglePassword1 =  document.querySelector('#togglePassword1');
const password1 = document.querySelector('#password');
togglePassword1.addEventListener('click', function (e) {
const type = password1.getAttribute('type') === 'password' ? 'text' : 'password';
password1.setAttribute('type', type);
 if (togglePassword1.src.match("eye-off-icon.svg")) {
        togglePassword1.src ="eye-icon.svg";
    } 
    else {
         togglePassword1.src ="eye-off-icon.svg";
     }
}); 


const togglePassword2 =  document.querySelector('#togglePassword2');
const password2 = document.querySelector('#confirm');
togglePassword2.addEventListener('click', function (e) {
const type = password2.getAttribute('type') === 'password' ? 'text' : 'password';
password2.setAttribute('type', type);
 if (togglePassword2.src.match("eye-off-icon.svg")) {
        togglePassword2.src ="eye-icon.svg";
    } 
    else {
         togglePassword2.src ="eye-off-icon.svg";
     }
});
 </script>
</body>
</html>