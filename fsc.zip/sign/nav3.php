<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        li{
            margin-top:10px;
            
        }
        .link1{
            float:left;
        }
        .link2{
            float:right;
        }
    </style>
</head>
<body>
    


      <ul class="nav col-12 col-md-auto mb-2 justify-content-around mb-md-0">
        <li><a href="home.php" class="nav-link px-2 link-secondary fs-5 link1">Home</a></li> 
        <li><a href="adminLogout.php" class="nav-link px-2 link-secondary fs-5 link2">Logout</a></li>  
      </ul>
     

    
</body>
</html>