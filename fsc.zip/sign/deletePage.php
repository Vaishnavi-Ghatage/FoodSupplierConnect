<?php

include 'connect.php';
if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    $sql="delete from `menu` where product_id=$id";
    $result=mysqli_query($con,$sql);
    if($result){
        header('location:Adminpage.php?deleted=true');
    }
    
}





?>