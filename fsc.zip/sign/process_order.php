<?php include 'connect.php'; ?>
<?php





// Retrieve the values of 'total' and 'food'
$total = $_GET['total'];
$food = $_GET['food'];

// Perform your database operation here, using $total and $food for comparison
$sql9 = "UPDATE `orders` SET payment_status='PAID',status='Ordered' WHERE food='$food' AND total='$total'";
$res9 = mysqli_query($con, $sql9);

// You might want to handle errors and return a response, if necessary






?>
