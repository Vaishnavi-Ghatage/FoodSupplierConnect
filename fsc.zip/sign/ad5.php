<?php
include 'connect.php';
?>
<?php 
// echo '<a href="home.php" class="nav-link px-2 link-secondary fs-5 link1"><span>Home</span></a>'; 
echo '<a href="adminLogout.php" class="nav-link px-2 link-secondary fs-5 link2"><span>Logout</span></a>'; 

session_start();
    $admin = $_SESSION['AdminID'];
    echo "<h2 style='text-align:center'>$admin</h2>";
    echo "<hr class='hr'>";
            ?>

<span style="font-family: verdana, geneva, sans-serif;"><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Page</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
  <style>
    </span>
<span style="font-family: verdana, geneva, sans-serif;">/*  import google fonts */
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap");
*{
  margin: 0;
  padding: 0;
  outline: none;
  border: none;
  text-decoration: none;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}
body{
  background: rgb(226, 226, 226);
}
nav{
  position: sticky;
  top: 0;
  bottom: 0;
  height: 100vh;
  left: 0;
  width: 90px;
  /* width: 280px; */
  background: #fff;
  overflow: hidden;
  transition: 1s;
}
nav:hover{
  width: 280px;
  transition: 1s;
}
.logo{
  text-align: center;
  display: flex;
  margin: 10px 0 0 10px;
  padding-bottom: 3rem;
}

.logo img{
  width: 45px;
  height: 45px;
  border-radius: 50%;
}
.logo span{
  font-weight: bold;
  padding-left: 15px;
  font-size: 18px;
  text-transform: uppercase;
}
a{
  position: relative;
  width: 280px;
  font-size: 14px;
  color: rgb(85, 83, 83);
  display: table;
  padding: 10px;
}
nav .fas{
  position: relative;
  width: 70px;
  height: 40px;
  top: 20px;
  font-size: 20px;
  text-align: center;
}
.nav-item{
  position: relative;
  top: 12px;
  margin-left: 10px;
}
a:hover{
  background: #eee;
}
a:hover i{
  color: #34AF6D;
  transition: 0.5s;
}
.logout{
  position: absolute;
  bottom: 0;
}

.container{
  display: flex;
}

/* MAin Section */
.main{
  position: relative;
  padding: 20px;
  width: 100%;
}
.main-top{
  display: flex;
  width: 100%;
}
.main-top i{
  position: absolute;
  right: 0;
  margin: 10px 30px;
  color: rgb(110, 109, 109);
  cursor: pointer;
}
.main .users{
  display: flex;
  width: 100%;
}
.users .card{
  width: 25%;
  margin: 10px;
  background: #fff;
  text-align: center;
  border-radius: 10px;
  padding: 10px;
  box-shadow: 0 20px 35px rgba(0, 0, 0, 0.1);
}
.users .card img{
  width: 70px;
  height: 70px;
  border-radius: 50%;
}
.users .card h4{
  text-transform: uppercase;
}
.users .card p{
  font-size: 12px;
  margin-bottom: 15px;
  text-transform: uppercase;
}
.users table{
  margin:  auto;
}
.users .per span{
  padding: 5px;
  border-radius: 10px;
  background: rgb(223, 223, 223);
}
.users td{
  font-size: 14px;
  padding-right: 15px;
}
.users .card button{
  width: 100%;
  margin-top: 8px;
  padding: 7px;
  cursor: pointer;
  border-radius: 10px;
  background: transparent;
  border: 1px solid #4AD489;
}
.users .card button:hover{
  background: #4AD489;
  color: #fff;
  transition: 0.5s;
}

/*Attendance List serction  */
.attendance{
  margin-top: 20px;
  text-transform: capitalize;
}
.attendance-list{
  width: 100%;
  padding: 10px;
  margin-top: 10px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 20px 35px rgba(0, 0, 0, 0.1);
}
/* .table{
  border-collapse: collapse;
  margin: 25px 0;
  font-size: 15px;
  min-width: 100%;
  overflow: hidden;
  border-radius: 5px 5px 0 0;
}
table thead tr{
  color: #fff;
  background: #34AF6D;
  text-align: left;
  font-weight: bold;
}
.table th,
.table td{
  padding: 12px 15px;
}
.table tbody tr{
  border-bottom: 1px solid #ddd;
}
.table tbody tr:nth-of-type(odd){
  background: #f3f3f3;
}
.table tbody tr.active{
  font-weight: bold;
  color: #4AD489;
} */
/* .table tbody tr:last-of-type{
  border-bottom: 2px solid #4AD489;
}
.table button{
  padding: 6px 20px;
  border-radius: 10px;
  cursor: pointer;
  background: transparent;
  border: 1px solid #4AD489;
}
.table button:hover{
  background: #4AD489;
  color: #fff;
  transition: 0.5rem;
} */
.clickable{
    cursor: pointer;
}
.hidden{
            display:none;
        }

</span>
  </style>
</head>
<body>
  <div class="container">
    


    <section class="main">
    



      <div class="users">
        <div class="card clickable">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16" class="ad">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
</svg>
          <h4>Add Product</h4>
          
        </div>
        <div class="card clickable" id="toggleDiv">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-exposure" viewBox="0 0 16 16">
  <path d="M8.5 4a.5.5 0 0 0-1 0v2h-2a.5.5 0 0 0 0 1h2v2a.5.5 0 0 0 1 0V7h2a.5.5 0 0 0 0-1h-2zm-3 7a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1z"/>
  <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0M1 8a7 7 0 1 1 14 0A7 7 0 0 1 1 8"/>
</svg>
          <h4>Edit Product</h4>
          
        </div>



        <div class="card clickable" id="toggleDiv">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
</svg>
          <h4>Remove Product</h4>
         
        </div>
        <div class="card clickable" id="toggleDiv2">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-bag-check" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M10.854 8.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L7.5 10.793l2.646-2.647a.5.5 0 0 1 .708 0"/>
  <path d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1m3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1z"/>
</svg>
          <h4>Orders</h4>
        
        </div>
      </div>

    <section id="hiddenSection2" class="hidden">
    
    <h2 style="text-align:center;">Dashboard</h2>
    
    <div class="cent">
    <?php
    echo '<h3 style="text-align:left; color:Maroon; text-align:center;">Today</h3>';
    date_default_timezone_set('Asia/Calcutta');
    $d=date("Y-m-d");
    $sql6 = "select count(*) as total_count from `orders` where product_supplier='$admin' and dateTime like '%$d%'";
    $result6 = mysqli_query($con,$sql6);
    // echo "$result6";
    if($result6->num_rows>0){
        $row=$result6->fetch_assoc();
        echo "<div style='text-align:center'>";
        echo "Total Orders: ".$row["total_count"];
        echo "</div>";
    }
    else{
        echo "0 results";
    }
    $sql27="select sum(total) as t_sales from `orders` where product_supplier='$admin' and dateTime like '%$d%' ";
    $result27 = mysqli_query($con,$sql27);
    // echo "$result6";
    if($result27->num_rows>0){
        $row=$result27->fetch_assoc();
        echo "<div style='text-align:center'>";
        echo "Total Sales: ₹ ".$row["t_sales"];
        echo "</div>";
    }
    else{
        echo "0 results";
    }

   

    $sql28="select count(*) as dl from `orders` where status='Delivered' and product_supplier='$admin' and dateTime like '%$d%' ";
    $result28 = mysqli_query($con,$sql28);
   
    if($result28->num_rows>0){
        $row=$result28->fetch_assoc();
        echo "<div style='text-align:center'>";
        echo "Delivered: ".$row["dl"];
        
    }
    else{
        echo "0 results";
    }

    echo "<br>";
      
    echo "<br>";
    echo '<h3 style="text-align:left; color:Maroon; text-align:center;">In this Month</h3>';
    $sql26 = "select count(*) as t_count from `orders` where product_supplier='$admin'";
    $result26 = mysqli_query($con,$sql26);
    // echo "$result6";
    if($result26->num_rows>0){
        $row=$result26->fetch_assoc();
        echo "<div style='text-align:center'>";
        echo "Total Orders: ".$row["t_count"];
        echo "</div>";
    }
    else{
        echo "0 results";
    }
      


    $sql7="select sum(total) as total_sales from `orders` where product_supplier='$admin' ";
    $result7 = mysqli_query($con,$sql7);
    // echo "$result6";
    if($result7->num_rows>0){
        $row=$result7->fetch_assoc();
        echo "<div style='text-align:center'>";
        echo "Total Sales: ₹ ".$row["total_sales"];
        echo "</div>";
    }
    else{
        echo "0 results";
    }

   

    $sql8="select count(*) as del from `orders` where status='Delivered' and product_supplier='$admin' ";
    $result8 = mysqli_query($con,$sql8);
    // echo "$result6";
    if($result8->num_rows>0){
        $row=$result8->fetch_assoc();
        echo "<div style='text-align:center'>";
        echo "Delivered: ".$row["del"];
        
    }
    else{
        echo "0 results";
    }

    echo "<br>";
    

    $sql8="select count(*) as dell from `cart` where product_supplier='$admin' ";
    $result8 = mysqli_query($con,$sql8);
    // echo "$result6";
    if($result8->num_rows>0){
        $row=$result8->fetch_assoc();
        echo "In Cart: ".$row["dell"];
        echo "</div>";
    }
    else{
        echo "0 results";
    }
   
?>
</div>
</div>
    <div class="container">
           
           <!-- <p>Vish</p> -->
                <div class="mb-4 pl-4 ">
                <table class="table table-hover table-bordered table2">
      
            
      <thead>
        <tr>
        
          <th scope="col">product_name</th>
          <th scope="col">product_quantity</th>
          <th scope="col">Total Price</th>
          <th scope="col">Order Date & Time</th>
          <th scope="col">Payment Type</th>
          <th scope="col">Payment Status</th>
          <th scope="col">Customer Name</th>
          <th scope="col">Customer contact</th>
          <th scope="col">Customer Email</th>
          <th scope="col">Customer Address</th>
          <th scope="col">Status</th>
          <th scope="col"></th>
    
        </tr>
      </thead>
      <tbody>
    <?php
    include 'connect.php';
    
        $admin = $_SESSION['AdminID'];
       
        $sql = "select * from `orders` where product_supplier='$admin'";
        $result = mysqli_query($con,$sql);
        if($result){
            while($row=mysqli_fetch_assoc($result)){
                $id=$row['id'];
                $product_name=$row['food'];
                $quantity=$row['quantity'];
                $total=$row['total'];
                $Order_Time=$row['dateTime'];
                $pay_type=$row['mode'];
                $pay_status=$row['payment_status'];
                $Customer_name=$row['cust_name'];
                $Customer_contact=$row['cust_contact'];
                $Customer_email=$row['cust_email'];
                $Customer_address=$row['cust_address'];
                $status=$row['status'];
                if($status=="Delivered"){
                    $pay_status="PAID";
                }
                else{
                    $pay_status="DUE";
                }
                echo '<tr>
                        <th scope="row">'.$product_name.'</th>
                        <td>'.$quantity.'</td>
                        <td>'.$total.'</td>
                        <td>'.$Order_Time.'</td>
                        <td>'.$pay_type.'</td>
                        <td>'.$pay_status.'</td>
                        <td>'.$Customer_name.'</td>
                        <td>'.$Customer_contact.'</td>
                        <td>'.$Customer_email.'</td>
                        <td>'.$Customer_address.'</td>
                        <td>'.$status.'</td>
                        <td><button onclick="reDirectTo('.$id.')" class="btn btn-primary">Update Order</button></td>
                        
                    </tr>
                ';
            }  
        }
    ?>
    
      </section>  
    
    
      </tbody>
    </table>
    </div>
    
    
            </div>







  </div> 

<script>
document.getElementById('toggleDiv').addEventListener('click',function(){
            var section=document.getElementById('hiddenSection');
            if(section.classList.contains('hidden')){
                section.classList.remove('hidden');
            }
            else{
                section.classList.add('hidden');
            }
        });

        document.getElementById('toggleDiv2').addEventListener('click',function(){
            var section=document.getElementById('hiddenSection2');
            if(section.classList.contains('hidden')){
                section.classList.remove('hidden');
            }
            else{
                section.classList.add('hidden');
            }
        });
</script>

</body>
</html>
