<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
     include 'connect.php';

    session_start();
    $admin = $_SESSION['AdminID'];

     $product_name=$_POST['name'];
     $product_desc=$_POST['desc'];
     $product_price=$_POST['price'];
     $product_image=$_POST['image'];
     $product_category=$_POST['cat'];
   
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suppliers</title>
   
    <style>
        .container{
            text-align:center;
            display:grid;
            margin-top:1rem;
            grid-template-columns:0.6fr 1fr;
            gap:5px;
           
          
           
            
        }
        .item2{
            display:grid;
            grid-template-columns:0.6fr;
            grid-template-rows:70px 70px 70px;
            gap:10px;
            grid-auto-flow: row;           
        }
        .item1{
            border:1px solid black;
            height: 230px;
        }
        .item{
            border:1px solid black;  
        }
        .clickable{
            cursor: pointer;
        }
        .w-col{
            width:500px;
        }
        .item21{
            color:black;
        }
        .item22{
            border:1px solid black;
            height: 150px;
        }
        .hidden{
            display:none;
        }
        .nav li{
            margin-top:10px;
            margin-left:65px;
        }
        .table{
            border:3px solid black;
        }
        .hr{
            background-color: black; /* Dark background color */
    border-color: black; /* Dark border color */
    height: 2px;
        }
        .v{
            align-items:center;
        }
        
       
    </style>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

<ul class="nav col-12 col-md-auto mb-2 justify-content-left mb-md-0">
        <li><a href="Admin.php" class="nav-link px-2 link-secondary fs-5">Back</a></li>
</ul>



<br>



    <div class="container mb-2">
        
    
      
            <div class="mb-4 pl-4 v">
            <table class="table table-hover table-bordered">
  
        
  <thead>
    <tr>
      <th scope="col">product_id</th>
      <th scope="col">product_name</th>
      <th scope="col">product_desc</th>
      <!-- <th scope="col">product_category</th> -->
      <th scope="col">product_price</th>
    
    </tr>
  </thead>
  <tbody>
<?php
include 'connect.php';
if(isset($_GET['showname'])){
    $id=$_GET['showname'];
   echo "<h2 style='color:maroon;'>$id</h2>";
   echo "<hr class='hr'>";
  
        $sql6 = "select count(*) as total_count from `orders` where product_supplier='$id'";
        $result6 = mysqli_query($con,$sql6);
        // echo "$result6";
        if($result6->num_rows>0){
            $row=$result6->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Total Orders: ".$row["total_count"];
            echo "</div>";
        }
        else{
            echo "0 results";
        }
          
    

        $sql7="select sum(total) as total_sales from `orders` where product_supplier='$id' ";
        $result7 = mysqli_query($con,$sql7);
        // echo "$result6";
        if($result7->num_rows>0){
            $row=$result7->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Total Sales: ₹ ".$row["total_sales"];
            echo "</div>";
        }
        else{
            echo "0 results";
        }

   

        $sql8="select count(*) as del from `orders` where status='Delivered' and product_supplier='$id' ";
        $result8 = mysqli_query($con,$sql8);
        // echo "$result6";
        if($result8->num_rows>0){
            $row=$result8->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Delivered: ".$row["del"];
            
        }
        else{
            echo "0 results";
        }

        echo "<br>";
        

        $sql8="select count(*) as dell from `cart` where product_supplier='$id' ";
        $result8 = mysqli_query($con,$sql8);
        // echo "$result6";
        if($result8->num_rows>0){
            $row=$result8->fetch_assoc();
            echo "In cart: ".$row["dell"];
            echo "</div>";
        }
        else{
            echo "0 results";
        }
         echo '<br>';
         echo '<br>';
       
         
 
         $profit = 0;
         $sql88 = "SELECT total FROM `orders` where product_supplier='$id'";
         $res88 = mysqli_query($con, $sql88);
         
         if ($res88->num_rows > 0) {
             while ($row = mysqli_fetch_assoc($res88)) {
                 $profit += ($row['total'] * 8) / 100; // Calculating 7% profit for each total
             }
         }
         echo "Total Profit Earned from ".$id.": ₹ " . $profit;

$sql = "select * from `menu` where product_supplier='$id'";
$result = mysqli_query($con,$sql);
if($result){
    while($row=mysqli_fetch_assoc($result)){
        $id=$row['product_id'];
        $name=$row['product_name'];
        $desc=$row['product_desc'];
        // $cat=$row['product_category'];
        $price=$row['product_price'];
        echo '<tr>
                <th scope="row">'.$id.'</th>
                <td>'.$name.'</td>
                <td>'.substr($desc,0,15).'...</td>
                <td>'.$price.'</td>
              
            </tr>
        ';
    }  
}
}
?>

    


  </tbody>
</table>

</div>
</div>






    <?php include 'footer.php'  ?>
  
</body>
</html>