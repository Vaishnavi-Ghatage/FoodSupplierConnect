<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home Page</title>
<style>
  .success-container {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: rgba(255, 255, 255, 0.9);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    z-index: 9999;
  }
  
  .success-symbol {
    font-size: 50px;
    color: green;
  }
</style>
</head>
<body>
<!-- Your items listing with add to cart button -->
<div class="item">
  <h3>Item 1</h3>
  <form method="post">
    <input type="hidden" name="item_id" value="1">
    <button type="submit" name="add_to_cart">Add to Cart</button>
  </form>
</div>

<div class="item">
  <h3>Item 2</h3>
  <form method="post">
    <input type="hidden" name="item_id" value="2">
    <button type="submit" name="add_to_cart">Add to Cart</button>
  </form>
</div>

<!-- Success message container -->
<?php
if (isset($_POST['add_to_cart'])) {
    // Logic to add item to cart
    // Assuming successful addition
    echo '
    <div class="success-container" id="success-container" style="display: block;">
      <div class="success-symbol">&#10004;</div>
      <div class="success-message">Item added to cart</div>
    </div>';
}
?>
</body>
</html>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        .success-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }

        .success-symbol {
            font-size: 50px;
            color: green;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <?php
    if (isset($_GET['added_to_cart']) && $_GET['added_to_cart'] == 'true') {
        echo '
            <div class="success-container" id="success-container">
                <div class="success-symbol">&#10004;</div>
                <div class="success-message">Item added to cart</div>
            </div>
        ';
    }
    ?>
    <!-- Your other HTML content here -->
    <script>
        // Wait for the DOM to be fully loaded
        document.addEventListener("DOMContentLoaded", function() {
            // Check if the success-container should be displayed
            var successContainer = document.getElementById("success-container");
            if (successContainer) {
                successContainer.style.display = "block";
                // Hide the success-container after 3 seconds
                setTimeout(function() {
                    successContainer.style.display = "none";
                }, 3000);
            }
        });
    </script>
</body>
</html>
