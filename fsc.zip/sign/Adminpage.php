<?php 
// echo '<a href="home.php" class="nav-link px-2 link-secondary fs-5 link1"><span>Home</span></a>'; 
echo '<a href="adminLogout.php" class="nav-link px-2 link-secondary fs-5 link2"><span>Logout</span></a>'; 

session_start();
    $admin = $_SESSION['AdminID'];
    echo "<h2 style='text-align:center'>$admin</h2>";
    echo "<hr class='hr'>";
            ?>

<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
     include 'connect.php';

    // session_start();
    // $admin = $_SESSION['AdminID'];

     $product_name=$_POST['name'];
     $product_desc=$_POST['desc'];
     $product_price=$_POST['price'];
     $product_image=$_POST['image'];
     $product_category=$_POST['cat'];
    //  $sql="insert into `Menu` (product_name,product_desc,product_price,product_image,product_supplier) values('$product_name','$product_desc','$product_price','$product_image','$admin')";
    //  $result = mysqli_query($con,$sql);


  
}
?>

<?php
// Check if item_deleted parameter is present in the URL
if(isset($_GET['logdin']) && $_GET['logdin'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
        <div class="success-symbol">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16" id="logddin">
        <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0z"/>
        <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708z"/>
    </svg>
    
        </div>
        <div class="success-message">Logged In Successfully!!</div>
    </div>
    ';
}
?>

<?php
if(isset($_GET['added']) && $_GET['added'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
        <div class="success-symbol">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-building-fill-check" viewBox="0 0 16 16" id="p_food">
  <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514"/>
  <path d="M2 1a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v7.256A4.5 4.5 0 0 0 12.5 8a4.5 4.5 0 0 0-3.59 1.787A.5.5 0 0 0 9 9.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .39-.187A4.5 4.5 0 0 0 8.027 12H6.5a.5.5 0 0 0-.5.5V16H3a1 1 0 0 1-1-1zm2 1.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5m3 0v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5m3.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zM4 5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5M7.5 5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5zm2.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5M4.5 8a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5z"/>
</svg>
        </div>
        <div class="success-message">Product Added Succesfully!!</div>
    </div>
    ';
}
?>

<?php
// Check if item_deleted parameter is present in the URL
if(isset($_GET['updated']) && $_GET['updated'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
       
        <div class="success-message">Product Updated Succesfully!!</div>
    </div>
    ';
}
?>

<?php
// Check if item_deleted parameter is present in the URL
if(isset($_GET['updated1']) && $_GET['updated1'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
       
        <div class="success-message">Order Status Updated Succesfully!!</div>
    </div>
    ';
}
?>

<?php
if(isset($_GET['deleted']) && $_GET['deleted'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
        <div class="success-symbol">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16" id="deleted">
                    <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                </svg>
        </div>
        <div class="success-message">Product Removed Succesfully!!</div>
    </div>
    ';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Page</title>
   
    <style>
         html,body{
            height:100%;
            margin:0;
            padding:0;
        }
        .container{
            text-align:center;
            display:grid;
            margin-top:2rem;
            grid-template-columns:0.6fr 1fr 0.6fr;
            gap:25px;
            min-height:60%;
            background-color:beige;
            margin-bottom:20px;
            /* max-height:90%; */
            /* height:60%; */
           
            
        }
       
        .item1{
            border:1px solid black;
            height: 230px;
            /* background-color:beige; */
            background-color:white;
        }
        .item2{
            display:grid;
            grid-template-columns:1fr;
            grid-template-rows:70px 70px 70px;
            gap:10px;
            grid-auto-flow: row;  
            /* background-color:beige;          */
            /* background-color:#CDAA7D; */
        }
        .item3{
            border:1px solid black;
            height: 230px;
            /* background-color:beige; */
            background-color:white;
        }
        .item{
            border:1px solid black;  
            /* background-color:beige; */
            background-color:white;
        }
        .clickable{
            cursor: pointer;
            display:flex;
            align-items:center;
            justify-content:center;
        }
        .w-col{
            width:500px;
        }
        .item21{
            color:black;
            /* background-color:beige; */
            background-color:white;
        }
        .item22{
            border:1px solid black;
            height: 150px;
            /* background-color:beige; */
            background-color:white;
        }
        .hidden{
            display:none;
        }
        
        .success-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }
    
        .success-symbol {
            font-size: 50px;
            color: green;
            margin-right: 10px;
        }
        #logddin{
            width:4rem;
            height:4rem;
            margin-left:30%;
        }
        #p_food{
            width:4rem;
            height:4rem;
            margin-left:35%;
        }
        #updated{
            width:4rem;
            height:4rem;
            margin-left:35%;
        }
        #deleted{
            width:4rem;
            height:4rem;
            margin-left:35%;
        }
        #add{
            height:2rem;
            width:2rem;
        }
        .cent{
            border:solid black 1px;
            margin-left:200px;
            margin-right:200px;
            margin-top:15px;
            background-color:white;
        }
        .btn{
            width:75px;
        }
       .table2{
        border:2px solid black;
       }
       .hr{
            background-color: black; /* Dark background color */
    border-color: black; /* Dark border color */
    height: 2px;
        }
        .c{
            background-color:beige;
        }
        .link2{
            margin-left:35px;
            margin-top:7px;
            
        }
        .link2 span{
            font-size:22px;
        }
        /* .link2{
            margin-left:35%;
            
            
        }
        .link span{
            font-size:22px;
        } */
        .foot{
            margin-top:70px;
        }
        .info{
            text-align:center;
            margin-top:15%;
        }
    </style>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>


<div class="c">


<br>
<?php
include 'connect.php';

    // $admin = $_SESSION['AdminID'];
   
?>

    <div class="container mb-1">
    <!-- onclick="redirect('info.php')" -->
        <div class="item1">
        <?php 
        
        $sql15="select information from `admin` where adminID='$admin'";
        $res15=mysqli_query($con,$sql15);
        if($res15->num_rows>0){
            while($row=$res15->fetch_assoc()){
                echo '<div class="info">'.$row["information"].'</div>';
            }
        }

        ?>
    </div>
        <div class="item2">
           <!-- <a href="addMenu.php" class="clickable"><div class="item item21">Add item</div></a>
           <a href="removeMenu.php" class="clickable"><div class="item item22">Remove item</div></a>
           <a href="editMenu.php" class="clickable"><div class="item item23">Edit item</div></a> -->
          <div class="clickable item" onclick="redirect('addMenu.php')">
          
          <div class="item21">Add Product</div>
          </div>  
          <!-- onclick="redirect('removeMenu.php')" -->
          <div class="clickable item22" id="toggleDiv">
          <div class="item21">Remove Product / Edit Product</div>
          </div> 
          <!-- onclick="redirect('editMenu.php')" -->
          <!-- <div class="clickable item">
          <div class="item21">Edit item</div>
          </div>  -->
            
        </div>
        <div class="item3 clickable" id="toggleDiv2">
            Orders
        </div>
        
        </div>
    
        <section id="hiddenSection" class="hidden">
            <!-- <?php
include 'connect.php';
session_start();
    $admin = $_SESSION['AdminID'];
            ?> -->
            <div class="container">
            <!-- <button class="btn btn-primary my-5 mb-4 mx-auto float-left bttn"  onclick="redirect('addMenu.php')">Add Item</button>
            <br><br> -->
       
            <div class="mb-4 pl-4 ">
            <table class="table table-hover table-bordered table1">
  
        
  <thead>
    <tr>
    
      <th scope="col">product_id</th>
      <th scope="col">product_name</th>
      <th scope="col">product_desc</th>
      <!-- <th scope="col">product_category</th> -->
      <th scope="col">product_price</th>
      <th scope="col" class="w-col">Operations</th>
    </tr>
  </thead>
  <tbody>
<?php

   
$sql = "select * from `menu` where product_supplier='$admin'";
$result = mysqli_query($con,$sql);
if($result){
    while($row=mysqli_fetch_assoc($result)){
        $id=$row['product_id'];
        $name=$row['product_name'];
        $desc=$row['product_desc'];
        // $cat=$row['product_category'];
        $price=$row['product_price'];
        echo '<tr>
                <th scope="row">'.$id.'</th>
                <td>'.$name.'</td>
                <td>'.substr($desc,0,15).'...</td>
                <td>'.$price.'</td>
                <td class="w-col">
                <button><a href="editPage.php?editid='.$id.'" class="btn btn-primary">Edit</a></button>
                <button><a href="deletePage.php?deleteid='.$id.'" class="btn btn-primary">Remove</a></button>
                </td>
            </tr>
        ';
    }  
}
?>

    


  </tbody>
</table>
</div>
        </div>
    </section>






    


    <section id="hiddenSection2" class="hidden">
    
        <h2 style="text-align:center;">Dashboard</h2>
        
        <div class="cent">
        <?php
        echo '<h3 style="text-align:left; color:Maroon; text-align:center;">Today</h3>';
        date_default_timezone_set('Asia/Calcutta');
        $d=date("Y-m-d");
        // $d='2024-03-20';
        // $sql6 = "select count(*) as total_count from `orders` where product_supplier='$admin' and dateTime like '%$d%'";
        $sql6 = "select count(*) as total_count from `orders` where product_supplier='$admin' and dateTime='$d'";
        $result6 = mysqli_query($con,$sql6);
        // echo "$result6";
        if($result6->num_rows>0){
            $row=$result6->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Total Orders: ".$row["total_count"];
            echo "</div>";
        }
        else{
            echo "0 results";
        }
        $sql27="select sum(total) as t_sales from `orders` where product_supplier='$admin' and dateTime like '%$d%' ";
        $result27 = mysqli_query($con,$sql27);
        // echo "$result6";
        if($result27->num_rows>0){
            $row=$result27->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Total Sales: ₹ ".$row["t_sales"];
            echo "</div>";
        }
        else{
            echo "0 results";
        }

       

        $sql28="select count(*) as dl from `orders` where status='Delivered' and product_supplier='$admin' and dateTime like '%$d%' ";
        $result28 = mysqli_query($con,$sql28);
       
        if($result28->num_rows>0){
            $row=$result28->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Delivered: ".$row["dl"];
            
        }
        else{
            echo "0 results";
        }

        echo "<br>";
          
        echo "<br>";
        echo '<h3 style="text-align:left; color:Maroon; text-align:center;">In this Month</h3>';
        $sql26 = "select count(*) as t_count from `orders` where product_supplier='$admin'";
        $result26 = mysqli_query($con,$sql26);
        // echo "$result6";
        if($result26->num_rows>0){
            $row=$result26->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Total Orders: ".$row["t_count"];
            echo "</div>";
        }
        else{
            echo "0 results";
        }
          


        $sql7="select sum(total) as total_sales from `orders` where product_supplier='$admin' ";
        $result7 = mysqli_query($con,$sql7);
        // echo "$result6";
        if($result7->num_rows>0){
            $row=$result7->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Total Sales: ₹ ".$row["total_sales"];
            echo "</div>";
        }
        else{
            echo "0 results";
        }

       

        $sql8="select count(*) as del from `orders` where status='Delivered' and product_supplier='$admin' ";
        $result8 = mysqli_query($con,$sql8);
        // echo "$result6";
        if($result8->num_rows>0){
            $row=$result8->fetch_assoc();
            echo "<div style='text-align:center'>";
            echo "Delivered: ".$row["del"];
            
        }
        else{
            echo "0 results";
        }

        echo "<br>";
        

        $sql8="select count(*) as dell from `cart` where product_supplier='$admin' ";
        $result8 = mysqli_query($con,$sql8);
        // echo "$result6";
        if($result8->num_rows>0){
            $row=$result8->fetch_assoc();
            echo "In Cart: ".$row["dell"];
            echo "</div>";
        }
        else{
            echo "0 results";
        }
       
?>
</div>
    </div>
            <div class="container">
           
       <!-- <p>Vish</p> -->
            <div class="mb-4 pl-4 ">
            <table class="table table-hover table-bordered table2">
  
        
  <thead>
    <tr>
    
      <th scope="col">product_name</th>
      <th scope="col">product_quantity</th>
      <th scope="col">Total Price</th>
      <th scope="col">Order Date & Time</th>
      <th scope="col">Payment Type</th>
      <th scope="col">Payment Status</th>
      <th scope="col">Customer Name</th>
      <th scope="col">Customer contact</th>
      <th scope="col">Customer Email</th>
      <th scope="col">Customer Address</th>
      <th scope="col">Status</th>
      <th scope="col"></th>

    </tr>
  </thead>
  <tbody>
<?php
include 'connect.php';

    $admin = $_SESSION['AdminID'];
   
    $sql = "select * from `orders` where product_supplier='$admin'";
    $result = mysqli_query($con,$sql);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
            $id=$row['id'];
            $product_name=$row['food'];
            $quantity=$row['quantity'];
            $total=$row['total'];
            $Order_Time=$row['dateTime'];
            $pay_type=$row['mode'];
            $pay_status=$row['status'];
            $Customer_name=$row['cust_name'];
            $Customer_contact=$row['cust_contact'];
            $Customer_email=$row['cust_email'];
            $Customer_address=$row['cust_address'];
            $status=$row['status'];
            if($status=="Delivered"){
                $pay_status="PAID";
            }
            else{
                $pay_status="DUE";
            }
            echo '<tr>
                    <th scope="row">'.$product_name.'</th>
                    <td>'.$quantity.'</td>
                    <td>'.$total.'</td>
                    <td>'.$Order_Time.'</td>
                    <td>'.$pay_type.'</td>
                    <td>'.$pay_status.'</td>
                    <td>'.$Customer_name.'</td>
                    <td>'.$Customer_contact.'</td>
                    <td>'.$Customer_email.'</td>
                    <td>'.$Customer_address.'</td>
                    <td>'.$status.'</td>
                    <td><button onclick="reDirectTo('.$id.')" class="btn btn-primary">Update Order</button></td>
                    
                </tr>
            ';
        }  
    }
?>

    


  </tbody>
</table>
</div>


        </div>
    </section>







<div class="foot">
    <?php include 'footer.php'  ?>
    </div>
    <script>
        function redirect(url){
            window.location.href=url;
        }

        document.getElementById('toggleDiv').addEventListener('click',function(){
            var section=document.getElementById('hiddenSection');
            if(section.classList.contains('hidden')){
                section.classList.remove('hidden');
            }
            else{
                section.classList.add('hidden');
            }
        });

        document.getElementById('toggleDiv2').addEventListener('click',function(){
            var section=document.getElementById('hiddenSection2');
            if(section.classList.contains('hidden')){
                section.classList.remove('hidden');
            }
            else{
                section.classList.add('hidden');
            }
        });
        function reDirectTo(id){
    var url2='updateStatus.php?id='+id;
    window.location.href=url2;
}

document.addEventListener("DOMContentLoaded", function() {
            // Check if the success-container should be displayed
            var successContainer = document.getElementById("success-container");
            if (successContainer) {
                successContainer.style.display = "block";
                // Hide the success-container after 3 seconds
                setTimeout(function() {
                    successContainer.style.display = "none";
                }, 1500);
            }
        });
    </script>
    </div>
</body>
</html>