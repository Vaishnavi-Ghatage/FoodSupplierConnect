<?php include 'connect.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
         *{
    box-sizing: border-box;   
    padding: 0;   
}
label,input{
    display: block;
    margin-top: 5px;
    min-width: 100%;   
}
form{   
    max-width: 500px;
    width: 90%;
    margin: auto;
    margin-top: 2rem;
    margin-bottom: 5rem;   
}
input{
    min-width: 100%;
    min-height: 5vh;
    border: 1px solid black;
    padding: 0.5rem;
    border-radius: 5px;
    height: 1rem;
}
label{
    font-weight: bolder;
    margin-top: 1rem;
}
    </style>
</head>
<body>
    <h2>Welcome to payment gateway</h2>
    <form action="pay.php" method="post">
        <label for="account">Account number</label>
        <input type="number" name="account">
        <label for="pin">Pin Number</label>
        <input type="number" name="pin">
        <label for="amount">Amount</label>
        <input type="number" name="amount" value="echo '$tital';">
        <label for="status">Status</label>
        <input type="text" name="status" value="DUE">
        <label for="ref">Reference Number</label>
        <!-- <input type="text"> -->
    </form>
</body>
</html>