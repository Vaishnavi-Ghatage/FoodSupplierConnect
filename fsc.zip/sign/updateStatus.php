<?php include 'connect.php' ?>

<?php

session_start();
if(isset($_GET['id'])){
    $id=$_GET['id'];
    
    $sql17="select * from `orders` where id='$id'";
    $res17=mysqli_query($con,$sql17);
    if($res17){
        while($row=mysqli_fetch_assoc($res17)){
        $name=$row['food'];
        $cust_name=$row['cust_name'];
        $cust_adr=$row['cust_address'];
        $cust_email=$row['cust_email'];
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            /* background-color:#DFD3E3; */
        }
        .cont{
            margin-left:30%;
            margin-top:3%;
            width:500px;
            border:solid black 1px;
            border-radius:10%;
            background-color:#DFD3E3;
        }
        .cont2{
            margin-left:15px;
        }
        .btn{
            text-align:center;
        }
       
        .link1{
            margin-left:35px;
            margin-top:7px;
            
        }
        .link1 p{
            font-size:22px;
        }
        /* #stat{
            margin-top:20px;
            
        } */
        .cont6{
            margin-left:15px;
            margin-right:15px;
            margin-top:10px;
            margin-bottom:10px;
            /* background-color:#DFD3E3; */
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    
    <div class="cont3">
    <a href="Adminpage.php" class="nav-link px-2 link-secondary fs-5 link1"><p>Back</p></a>
<div class="cont">
    <div class="cont6">
    <h2 style="margin-left:15px;" id="stat">Update product status</h2>
    <hr>
    <div class="cont2">
        <br>
    <form action="" method="post">

       <label for="name">Product Name:</label>
       <input type="text" id="name" value='<?php echo $name ?>' readonly>
       <br><br>
       <label for="cust_name">Customer Name:</label>
       <input type="text" id="cust_name" value='<?php echo $cust_name ?>' readonly>
       <br><br>
       <label for="cust_address">Customer Address:</label>
       <input type="text" id="cust_adr" value='<?php echo $cust_adr ?>' readonly>
       <br><br>
       <label for="order_status">Order Status:</label>
       <select name="order_status" id="order_status">
       <option value="Ordered">Ordered</option>
       <option value="On delivery">On delivery</option>
       <option value="Delivered">Delivered</option>
       <option value="Cancelled">Cancelled</option>
       </select>
       <br><br>
       <input type="submit" name="submit" value="Update" class="btn btn-primary">

    </form>
    </div>
    </div>
</div>
</div>




 



<?php
 if(isset($_POST['submit'])){
    $status=$_POST['order_status'];
    // $mode=$_POST['mode'];
    // $payStatus="PAID";
    
        $sql = "update `orders` set status='$status' where id='$id' ";
    

    

    $res = mysqli_query($con,$sql);
    if($res){
        
        echo '<script>window.location.href="Adminpage.php?updated1=true";</script>';
    }
    else{
        echo '<script>alert("Update Failed");</script>';
        echo '<script>setTimeout(function(){window.location.href="Adminpage.php";},50);</script>';
    }
}




?>

</body>
</html>