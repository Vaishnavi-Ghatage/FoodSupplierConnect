<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
     include 'connect.php';

     $category_id=$_POST['category_id'];
     $category_name=$_POST['category_name'];
     $category_desc=$_POST['category_desc'];
     $category_price=$_POST['category_price'];
     $category_image=$_POST['category_image'];

     $sql="insert into `clothes_table` (category_id,category_name,category_desc,category_price,category_image) values('$category_id','$category_name','$category_desc','$category_price','$category_image')";

     $result = mysqli_query($con,$sql);
  
}
?>











<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <form action="" method="POST">
            <label for="category_id"></label>
            <input type="text" name="category_id">
            <label for="category_name"></label>
            <input type="text" name="category_name">
            <label for="category_desc"></label>
            <input type="text" name="category_desc">
            <label for="category_price"></label>
            <input type="text" name="category_price">
            <label for="category_image"></label>
            <input type="text" name="category_image">

        </form>
    </div>
</body>
</html>