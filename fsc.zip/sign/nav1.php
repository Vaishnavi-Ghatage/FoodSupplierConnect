<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        
    </style>
</head>
<body>
    


      <ul class="nav col-12 col-md-auto mb-2 justify-content-around mb-md-0">
        <li><a href="home.php" class="nav-link px-2 link-secondary fs-5">Home</a></li>
        <li><a href="home.php#browse_cuisines" class="nav-link px-2 fs-5">Browse Cuisines</a></li>
        <li><a href="#" class="nav-link px-2 fs-5">About</a></li>
        <li><a href="#" class="nav-link px-2 fs-5">Order</a></li>
        <li><a href="adminlogin.php" class="nav-link px-2 fs-5">Admin</a></li>
        
      </ul>

    
</body>
</html>