<?php

if(!isset($_SESSION['username2'])){
    $_SESSION['no-login-message']="<div class='error'>Please LogIn to Access the page</div>";
    header('location:signup.php');
}






?>