<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menu</title>
  <style>
    /* CSS styles for your menu */
  </style>
</head>
<body>
  <div id="categories">
    <!-- Display categories here -->
    <div class="category" onclick="showProducts('breakfast')">Breakfast</div>
    <div class="category" onclick="showProducts('thali')">Thali</div>
    <!-- Add more categories as needed -->
  </div>

  <div id="products">
    <!-- Product divs will be dynamically added here -->
  </div>

  <script>
    function showProducts(category) {
      // Send an AJAX request to the server to fetch products for the given category
      // Update the 'products' div with the retrieved products
      // Example:
      fetch(/getProducts?category=${category})
        .then(response => response.json())
        .then(products => {
          const productsDiv = document.getElementById('products');
          productsDiv.innerHTML = ''; // Clear previous products
          products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.innerHTML = `
              <img src="${product.image}" alt="${product.name}">
              <h3>${product.name}</h3>
              <p>${product.price}</p>
              <button>Order Now</button>
            `;
            productsDiv.appendChild(productDiv);
          });
        })
        .catch(error => console.error('Error fetching products:', error));
    }
  </script>
</body>
</html>