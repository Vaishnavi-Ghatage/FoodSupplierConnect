<?php
$success=0;
$user=0;
$pass=0;
$empt=0;
$invalid=0;

    if($_SERVER['REQUEST_METHOD']=='POST'){
        session_start();
     include 'connect.php';

    if(isset($_POST['signup-submit'])){
    $username=$_POST['username'];
     $email=$_POST['email'];
     $password=$_POST['password'];
     $confirm_pass=$_POST['confirm'];

    if(empty($username)){
        $empt=1;
    }
    else if(empty($email)){
        $empt=1;
    }
    else{

    $sql = "select * from `signin` where username='$username' OR email='$email'";
    $result = mysqli_query($con,$sql);

    if($result){
        $num = mysqli_num_rows($result);
        if($num>0){
          
            $user=1;
        }
        else{
            if($password===$confirm_pass){
            $sql="insert into `signin` (username,email,password) values('$username','$email','$password')";
            $result = mysqli_query($con,$sql);
            if($result){
                $success=1;
                $_SESSION['loggedin']=true;
                
                $_SESSION['username1']=$username;
                header('location:home.php?logdin=true');
                exit;
            }
            else{
                die(mysqli_error($con));
            }
        }
        else{
            $pass=1;
        }
        }
    } 
}
}


if(isset($_POST['signin-submit'])){
    // include 'loginCheck.php';
    $username=$_POST['username'];
     $password=$_POST['password'];
    if(empty($username)){
        $empt=1;
    }
    else{
    $sql = "select * from `signin` where username='$username' AND password='$password' ";
    $result = mysqli_query($con,$sql);
    if($result){
        $num = mysqli_num_rows($result);
        if($num>0){
            $success=1;
            $_SESSION['loggedin']=true;
                $_SESSION['username2']=$username;
                
                header('location:home.php?logdin=true');
                exit;
           
        }
        else{
            $invalid=1;
        }    
        }
    } 
}


    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>     
        /* *{
    box-sizing: border-box;   
    padding: 0;  
   
} */
/* body{
    background-image:url("images\bg.jpeg");
    background-size:cover;
    background-repeat:no-repeat;
    filter:blur(5px);
} */
body {
    position: relative;
}

*::before {
    box-sizing: border-box;   
    padding: 0;
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%; 
    background-image: url('bg4.jpeg');
   background-size: cover;
    background-repeat: no-repeat;
    filter: blur(1px);  
    z-index: -1;
}

.container{
    margin-top: 10px;
    align-items: center;
    max-width: 600px;
    margin: auto;
    width: 90%;
    border-radius: 10px;
    margin-bottom: 10px; 
    border:1px solid black;
    overflow:hidden;
    
}
label,input{
    display: block;
    margin-top: 5px;
    min-width: 100%;   
}
form{   
    max-width: 500px;
    width: 90%;
    margin: auto;
    margin-top: 2rem;
    margin-bottom: 2rem;   
}
.sign input{
    min-width: 100%;
    min-height: 5vh;
    border: 1px solid black;
    padding: 0.5rem;
    border-radius: 5px;
    height: 1rem;
}
label{
    font-weight: bolder;
    margin-top: 1rem;
}
.btn{
    font-weight: bold;
    
}
.btn:hover{
    background-color: #F7E7CE;
    border:1px solid black;
}
.bttn{
    max-width: 300px;
    width: 100px;
    align-items: center;
    background-color: #F7E7CE;
    color: BLACK;
    font-weight: bold;
    border-radius: 5px;
    padding: 5px;
    align-self: center;
}
.sec1{
            display:none;
        }
.btttn{
    float:right;
}
.bttttn{
    width:180px;
}

        input[type="submit"]{
            height:35px;
            background-color: #F7E7CE;
        }
     #logo1{
        margin-top:5px;
     }
    </style>
</head>
<body>
       
   <div>
<?php
        if($empt){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Please</strong> Enter username and password!!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
        <?php
        if($user){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Ohh No!</strong> User Already Exist.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
       <?php
        if($success){
             echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
             You are succesfully Logged In!!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
<?php
        if($pass){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
             <strong>Ohh No!</strong>Password did not match!!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
<?php
        if($invalid){
             echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error! </strong> Invalid Credentials.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div> ';
        }
?>
 <center>
        <img src="images\logo-in.jpeg" alt="logo" height="100px" width="250px" id="logo1">
        </center>
  <div class="container mt-3">

    <div class="buttons button-container mt-2">
    <button class="signup-btn bttn">Sign up</button>
    <button class="signin-btn bttn">Log in</button>
    <button class="btttn bttn bttttn" onclick="reDirectTo()">Admin Login</button>
</div>
<div class="section sec1 signin-section" id="vish">
        <form  method="POST" class="signin-form sign" action="index.php">
        <div>
        <label for="username">Username:</label>
        <input type="text/email"  name="username" id="username" placeholder="Enter Username/Email" autocomplete='off'>
        </div>
        <div style="position: relative;">
    <label for="password">Password :</label>
    <input type="password" name="password" id="password3" placeholder="Enter Password" autocomplete='off'>
    <img src="eye-off-icon.svg" width="23px" height="23px" 
        style="position: absolute; right: 5px; top: 90%; transform: translateY(-90%);" id="togglePassword3">
</div>

        <div>
            <input type="submit" value="SignIn" class="btn" name="signin-submit">
        </div>
        </form>
        </div>
       <div class="section signup-section">
    <form method="POST" class="signup-form sign" action="index.php">
        <div>
            <label for="username">Username :</label>
        <input type="text"  name="username" id="username" placeholder="Enter Username" autocomplete='off'>
        </div>
        <div>
            <label for="email" >Email :</label>
        <input type="email" name="email" id="email" placeholder="Enter your Email" autocomplete='off'>
        </div>

        <div style="position: relative;">
    <label for="password">Password :</label>
    <input type="password" name="password" id="password" placeholder="Enter Password" autocomplete='off'>
    <img src="eye-off-icon.svg" width="23px" height="23px" 
        style="position: absolute; right: 5px; top: 90%; transform: translateY(-90%);" id="togglePassword1">
</div>

        <div style="position: relative;">
    <label for="confirm">Confirm Password :</label>
    <input type="password" name="confirm" id="confirm" placeholder="Enter Password again" autocomplete='off'>
    <img src="eye-off-icon.svg" width="23px" height="23px" 
        style="position: absolute; right: 5px; top: 90%; transform: translateY(-90%);" id="togglePassword2">
</div>

            <input type="submit" value="submit" class="btn mt-2" name="signup-submit">
        </div>      
 </form>
</div>
</div>
<script>
document.querySelector(".signin-btn").addEventListener("click", function() {
    document.querySelector(".signup-section").style.display = "none";
    document.querySelector(".signin-section").style.display = "block";
});
document.querySelector(".signup-btn").addEventListener("click", function() {
    document.querySelector(".signin-section").style.display = "none";
    document.querySelector(".signup-section").style.display = "block";
});

const togglePassword1 =  document.querySelector('#togglePassword1');
const password1 = document.querySelector('#password');
togglePassword1.addEventListener('click', function (e) {
const type = password1.getAttribute('type') === 'password' ? 'text' : 'password';
password1.setAttribute('type', type);
 if (togglePassword1.src.match("eye-off-icon.svg")) {
        togglePassword1.src ="eye-icon.svg";
    } 
    else {
         togglePassword1.src ="eye-off-icon.svg";
     }
}); 

const togglePassword2 =  document.querySelector('#togglePassword2');
const password2 = document.querySelector('#confirm');
togglePassword2.addEventListener('click', function (e) {
const type = password2.getAttribute('type') === 'password' ? 'text' : 'password';
password2.setAttribute('type', type);
 if (togglePassword2.src.match("eye-off-icon.svg")) {
        togglePassword2.src ="eye-icon.svg";
    } 
    else {
         togglePassword2.src ="eye-off-icon.svg";
     }
}); 

const togglePassword3 =  document.querySelector('#togglePassword3');
const password3 = document.querySelector('#password3');
togglePassword3.addEventListener('click', function (e) {
const type = password3.getAttribute('type') === 'password' ? 'text' : 'password';
password3.setAttribute('type', type);
 if (togglePassword3.src.match("eye-off-icon.svg")) {
        togglePassword3.src ="eye-icon.svg";
    } 
    else {
         togglePassword3.src ="eye-off-icon.svg";
     }
});

function reDirectTo(){
    window.location.href="adminlogin.php";
} 
</script>
</div>
</body>
</html>