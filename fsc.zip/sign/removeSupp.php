<?php

include 'connect.php';
if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    $sql="delete from `admin` where count=$id";
    $result=mysqli_query($con,$sql);
    if($result){
        header('location:Admin.php?deleted=true');
    }
    
}





?>