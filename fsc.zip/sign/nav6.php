<?php include 'connect.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      *{
        color:black;
      }
      .align-right{
        float : right;
        margin-left:580px;
      }
      /* @media screen and (max-width:1000px){
        #srch{
          float : right;
        margin-left:610px;
        }
      } */
      @media (max-width: 1200px) and (min-width: 650px){
        #srh{
          margin-left:10px;
        }
      } 
      #logo{
        margin-left:7%;
      }
      /* @media (max-width: 600px) and (min-width: 400px){
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
  <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
</svg>

      } */
       @media screen and (max-width: 650px){
        #srh{
          display:none;
        }
        #cart{
          margin-left:20%
        }
      }
      #cart{
        height:1.5rem;
        width:1.5rem;
      }
      /* #sr{
        border-radius:5px;
      } */
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>




<nav class="navbar bg-body-tertiary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="images/logo-in.jpeg" alt="logo" height="70px" width="210px" id="logo"></a>
    <!-- <a href="home.php#nav#srch"><img src="search.svg" alt="search" class="img-fluid align-right"></a> -->
    
    
    <!-- <nav class="navbar bg-body-tertiary align-right">
  <div class="container-fluid">
    <form class="d-flex" role="search" action="food-search.php" method="post">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit" name="search">Search</button> -->
      <!--<input type="submit" name="submit" value="Search" class="btn btn-outline-success">
    </form>
  </div>
</nav> -->

<nav class="navbar bg-body-tertiary align-right" id="srh">
  <div class="container-fluid ">
    <form class="d-flex" role="search" action="food-search.php" method="post">
      <input class="form-control me-2" type="search" name="search" placeholder="Search for food....." aria-label="Search">
      <button class="btn btn-outline-success" type="submit" name="submit">Search</button>
    </form>
  </div>
</nav>
<!-- <section class="food-search text-center" id="srch">
            <div class="container">
              <form action="food-search.php" method="post">
                <label for="search">Search</label>
                <input type="search" name="search" placeholder="search for food...." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
              </form>
            </div>
          </section> -->
<a href="cart.php">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-cart-check" viewBox="0 0 15 14" id="cart">
<path d="M11.354 6.354a.5.5 0 0 0-.708-.708L8 8.293 6.854 7.146a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0z"></path>
<path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"></path>
</svg></a>

 <!-- <section class="food-search text-center align-right" id="srch">
            <div class="container-fluid">
              <form class="d-flex" action="food-search.php" method="post">
                <input type="search" id="srch" class="form-control me-2" name="search" aria-label="Search" placeholder="search for food...." required>
                <input type="submit" name="submit" value="Search" class="btn btn-outline-success">
              </form>
            </div>
          </section> -->

    <button class="navbar-toggler"  id="nav" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
      
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Offcanvas</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="home.php#browse_cuisines">Browse Cuisines</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Filter By Category
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="home.php#Breakfast">Breakfast</a></li>
              <li><a class="dropdown-item" href="home.php#Homemade">Homemade</a></li>
              <li><a class="dropdown-item" href="home.php#Main Course">Main Course</a></li>
              <li><a class="dropdown-item" href="home.php#Snacks">Snacks</a></li>
              <li><a class="dropdown-item" href="home.php#Desserts and ColdDrinks">Desserts and ColdDrinks</a></li>
              <li><a class="dropdown-item" href="home.php#Thali">Thali</a></li>
              <!-- <li><a class="dropdown-item" href="home.php#Non-Veg">Non-Veg</a></li> -->
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="order_history.php">Your Orders</a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" href="cart.php">Cart</a>
          </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link" href="adminlogin.php">Admin Login</a>
          </li> -->
          


          <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
       
          
          <section class="food-search text-center" id="srch">
            <div class="container">
              <form action="food-search.php" method="post">
                <label for="search">Search</label>
                <input type="search" name="search" placeholder="search for food...." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
              </form>
            </div>
          </section>
          </ul>
        <!-- <form class="d-flex mt-3" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form> -->
      </div>
    </div>
  </div>
</nav>


</body>
</html>