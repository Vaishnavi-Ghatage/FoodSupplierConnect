<?php


$con = mysqli_connect('localhost','root','','foodsupplierconnect');
if(!$con){
    die("connection failed".mysqli_error());
}


?>