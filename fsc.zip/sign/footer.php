<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .container1{
            color:white;
           
        }
    </style>
</head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<body>
    <div class="container1 bg-dark">
<p class="col-md-4 mb-0 ">© 2024 FSC</p>



<ul class="nav col-md-12 justify-content-around">
  <li class="nav-item"><a href="home.php" class="nav-link px-2">Home</a></li>
  <li class="nav-item"><a href="home.php#browse_cuisines" class="nav-link px-2">Browse Cuisines</a></li>
  <li class="nav-item"><a href="about.php" class="nav-link px-2">About us</a></li>
  <li class="nav-item"><a href="order_history.php" class="nav-link px-2">Order</a></li>
  <li class="nav-item"><a href="adminlogin.php" class="nav-link px-2">Admin</a></li>
</ul>
</div>
</body>
</html>