<a href="home.php" class="nav-link px-2 link-secondary fs-5 link1">Home</a>
<?php include 'connect.php' ?>

<?php
if(isset($_GET['prDel']) && $_GET['prDel'] == 'true') {
    echo '
    <div class="success-container" id="success-container">
        <div class="success-symbol">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-x-circle" viewBox="0 0 16 16" id="prDel">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
</svg>

        </div>
        <div class="success-message">Order Cancelled Succesfully!!</div>
    </div>
    ';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
      .success-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }
    
        .success-symbol {
            font-size: 50px;
            color: green;
            margin-right: 10px;
        }
        #prDel{
            width:4rem;
            height:4rem;
            margin-left:35%;
        }
        .table{
            border:2px solid black;
        }
        .link1{
            margin-left:35px;
            margin-top:7px;
            
        }
        .link1 p{
            font-size:22px;
        }
    </style>
</head>
<body>


    <?php
session_start();
if(isset($_SESSION['username1']) || (isset($_SESSION['username2']))){
    // $un=$_SESSION['username1'];
    if(isset($_SESSION['username1'])){
        $un=$_SESSION['username1'];
    }
    else{
        $un=$_SESSION['username2'];
    }
    

    $sql9="select email from `signin` where username='$un'";
    $res9=mysqli_query($con,$sql9);
    $row9=mysqli_fetch_assoc($res9);
    $email=$row9['email'];
    
    $sql20="select food,price,quantity,total,dateTime,status from `orders` where username='$un' and email='$email'";
  $res20=mysqli_query($con,$sql20);
  if(mysqli_num_rows($res20)<1){
    echo "<p>Oops!! We can't smell any food here.Go back and <a href='home.php#browse_cuisines'>Order now</a>.</p>";
    exit;
}


    echo '<div class="container">
           
   <h2 style="text-align:center;">Your Order History</h2>
   <br>
         <div class="mb-4 pl-4 c2">

    <table class="table table-hover table-bordered ">
  
        
    <thead>
      <tr>
      
        <th scope="col">product_name</th>
        <th scope="col">Product Price</th>
        <th scope="col">product_quantity</th>
        <th scope="col">Total Price</th>
        <th scope="col">Order Date & Time</th>
        <th scope="col">Status</th>
        <th scope="col">Operations</th>
        
  
      </tr>
    </thead>
    <tbody>';

  
     
    
  $sql10="select id,food,price,quantity,total,dateTime,status from `orders` where username='$un' and email='$email'";
  $res10=mysqli_query($con,$sql10);
 
      if($res10){
          while($row=mysqli_fetch_assoc($res10)){
              $pid=$row["id"];
              $product_name=$row["food"];
              $price=$row["price"];
              $quantity=$row["quantity"];
              $total=$row["total"];
              $Order_Time=$row["dateTime"];
              $status=$row["status"];
              if($status=="Ordered"){
              echo "<tr>
                      <th scope=`row`>".$product_name."</th>
                      <td>".$price."</td>
                      <td>".$quantity."</td>
                      <td>".$total."</td>
                      <td>".$Order_Time."</td>
                      <td>".$status."</td>
                      <td>
                      <form method='post' action='cancOrd.php'>
                      <input type='hidden' name='pid' value='$pid'>
                      <input type='submit' value='Cancel Order'>
                      </form>
                      </td>
                      
                      
                  </tr>
              ";
              }
              // <button id='cancel' onclick='toggleButtons(".$pid.")'>Cancel Order</button>
              //         <button id='confirm' style='display:none;'>Confirm</button>
              else{
                echo "<tr>
                      <th scope=`row`>".$product_name."</th>
                      <td>".$price."</td>
                      <td>".$quantity."</td>
                      <td>".$total."</td>
                      <td>".$Order_Time."</td>
                      <td>".$status."</td>
                      
                      
                      
                  </tr>
              ";
              }
          }  
      }
      

    echo "</tbody>
  </table>

</div>
</div>";






}





?>

<script>
  function reDirectTo(url){
            window.location.href=url;
        }

function toggleButtons(pid){
  var ppid=pid;
  var cancel_btn=document.getElementById("cancel");
  var confirm_btn=document.getElementById("confirm");

  cancel_btn.style.display="none";
  confirm_btn.style.display="block";

  confirm_btn.addEventListener("click",function(){
    <?php


?>
  });
}

document.addEventListener("DOMContentLoaded", function() {
            // Check if the success-container should be displayed
            var successContainer = document.getElementById("success-container");
            if (successContainer) {
                successContainer.style.display = "block";
                // Hide the success-container after 3 seconds
                setTimeout(function() {
                    successContainer.style.display = "none";
                }, 1500);
            }
        });


</script>


</body>
</html>