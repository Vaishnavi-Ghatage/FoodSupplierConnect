<a href="home.php" class="nav-link px-2 link-secondary fs-5 link1">Home</a>

<?php include 'connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
        color:black;
      }
      h2{
        text-align:center;
        
      }
      .carousel-item img{
        padding: 5px;
      }
      .container{
            background-color:#C7C8CC;
        }
        .hr{
            background-color: black; /* Dark background color */
    border-color: black; /* Dark border color */
    height: 2px;
        }
      /* .box:hover{
		transform: scale(1.1);
		z-index: 2;
    border:2px solid black;
    
	} */
  .link1{
            margin-left:35px;
            margin-top:10px;
            
        }
        .link1 p{
            font-size:25px;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
</head>
<body>
<div class="container mt-3">
      
      <div class="row">

<?php
 
$search=$_POST["search"];
echo "<h2 style='margin-top:8px;'>Foods on your Search '".$search."'</h2>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<hr class='hr'>";
$sql="select * from `menu` where product_name like '%$search%' or product_desc like '%$search%' ";
$res=mysqli_query($con,$sql);
$count=mysqli_num_rows($res);

if($count>0){
  while($row=mysqli_fetch_assoc($res)){
      $id=$row['product_id'];
                      $name=$row['product_name'];
                      $desc=$row['product_desc'];
                      $price=$row['product_price'];
                      $image=$row['product_image'];
                      $cat=$row['product_category'];
                      $supp=$row['product_supplier'];

                   

                      echo '<div class="col-md-4 col-sm-6 col-xm-12 mb-5">
                      <div class="card box">
                          <img src='.$image.' class="card-img-top" alt="product photo" style="height:300px; object-fit:contain" >
                          <div class="card-body">
                              <h5 class="card-title">'.$name.'</h5>
                              <p class="card-text">'.substr($desc,0,65).'....</p>
                              <p>'.$price.'/-</p>
                              <a href="order.php?id='.$id.'&supp='.$supp.'" class="btn btn-primary">Order Now</a>
                          </div>
                      </div>
                      </div>';
  }
}
else{
  echo "<div class='error'>Product not found....</div>";
}
?>
</div>
</div>
</body>
</html>

