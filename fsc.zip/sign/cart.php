<a href="home.php" class="nav-link px-2 link-secondary fs-5 link1"><p>Home</p></a>
<?php include 'connect.php' ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <style>
        .box:hover{
		transform: scale(1.1);
		z-index: 2;

	}
    .success-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }
        

        .success-symbol {
            font-size: 50px;
            color: green;
            margin-right: 10px;
        }
        #remCart{
            width:3rem;
            height:3rem;
            margin-left:40%;
        }
        .container{
            background-color:#C7C8CC;
        }
        .hr{
            background-color: black; /* Dark background color */
    border-color: black; /* Dark border color */
    height: 2px;
        }
        .link1{
            margin-left:35px;
            margin-top:7px;
            
        }
        .link1 p{
            font-size:22px;
        }
       
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    









<?php

session_start();
if(isset($_SESSION['username1']) || (isset($_SESSION['username2']))){
    // $un=$_SESSION['username1'];
    if(isset($_SESSION['username1'])){
        $un=$_SESSION['username1'];
    }
    else{
        $un=$_SESSION['username2'];
    }
}
    ?>


<div class="container mt-2">
    
         <h2 style="text-align:center;font-family: cursive;font-size:35px;" class="mt-2">My Cart</h2>
         <hr class="hr">
              <div class="row">
                <?php
    $sql9="select email from `signin` where username='$un'";
    $res9=mysqli_query($con,$sql9);
    $row9=mysqli_fetch_assoc($res9);
    $email=$row9['email'];

    $sql10="select * from `cart` where cust_name='$un' and cust_email='$email'";
    $res10=mysqli_query($con,$sql10);
    if(mysqli_num_rows($res10)<1){
        echo "<p>Oops!! We can't smell any food here.Go back and <a href='home.php#browse_cuisines'>Add now</a>.</p>";
    }
    if($res10){
        while($row=mysqli_fetch_assoc($res10)){
            $id=$row['product_id'];
            $product_name=$row['product_name'];
            $product_price=$row['product_price'];
            $product_image=$row['product_image'];
            $supp=$row['product_supplier'];
            

            echo '<div class="col-md-4 col-sm-6 col-xm-12 mb-5 i1">
                        <div class="card">
                        
                            <img src='.$product_image.' class="card-img-top box" alt="product photo" style="height:300px; object-fit:contain" >
                            <div class="card-body">
                                <h5 class="card-title">'.$product_name.'</h5>
                                <p>'.$product_price.'/-</p>
                                
                                <a href="order.php?id='.$id.'&supp='.$supp.'" class="btn btn-primary">Order Now</a>
                                <a href="removeCart.php?id='.$id.'&un='.$un.'" class="btn btn-primary">Remove</a>
                          
                                </div>
                        </div>
                        </div>
                        ';
                        
        }  
    }
    ?>
    </div>
    </div>




    <?php
    // Check if item_deleted parameter is present in the URL
    if(isset($_GET['item_deleted']) && $_GET['item_deleted'] == 'true') {
        echo '
        <div class="success-container" id="success-container">
            <div class="success-symbol">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16" id="remCart">
                    <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                </svg>
            </div>
            <div class="success-message">Product removed from the Cart</div>
        </div>
        ';
    }
    ?>


<script>
    document.addEventListener("DOMContentLoaded", function() {
            // Check if the success-container should be displayed
            var successContainer = document.getElementById("success-container");
            if (successContainer) {
                successContainer.style.display = "block";
                // Hide the success-container after 3 seconds
                setTimeout(function() {
                    successContainer.style.display = "none";
                }, 2000);
            }
        });
</script>
</body>
</html>