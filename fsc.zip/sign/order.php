<a href="home.php" class="nav-link px-2 link-secondary fs-5 link1"><p>Home</p></a>
<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
     include 'connect.php';

     session_start();
if(isset($_SESSION['username1']) || (isset($_SESSION['username2']))){
    // $un=$_SESSION['username1'];
    if(isset($_SESSION['username1'])){
        $un=$_SESSION['username1'];
    }
    else{
        $un=$_SESSION['username2'];
    }
    

    $sql9="select email from `signin` where username='$un'";
    $res9=mysqli_query($con,$sql9);
    $row9=mysqli_fetch_assoc($res9);
    $email=$row9['email'];
    

    // $sql10="select food,price,quantity,total,dateTime,status from `orders` where cust_name"
}
}
?>

<?php include 'connect.php' ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Food</title>
    <style>
        *{
            margin-left:10px;
           /* background:url('bg90.jpeg'); */
        }
        
     /* body{
        background-image: url('order-bg.jpeg');
     } */
        .cont1{
            margin-left:7%;
            border:solid 2px black;
            margin-right:25%;
            background-color:#FFFFF0;
        }
       li{
            margin-top:10px;
            list-style-type: none;
            
        }
        .link1{
            float:left;
            font-size:20px;
        
        }
        .card{
            margin-left:25px;
            display:flex;
            /* justify-co
             */
             gap:40px;
             
        }
        label,input{
            display:block;
            max-width: 90%;
            

        }
        form label{
            font-size:1.2rem;
            margin-left:25px;
            margin-bottom:8px;

        }
        form input{
            width:500px;
            margin-left:25px;
            margin-bottom:8px;
        }
        input{
            border:1px solid black;
            height:25px;
        }
        #qnt_label{
            margin-left:8%;
        }
        #qnty_ip{
            width:150px;
            margin-left:8%;
        }
        select{
            margin-top:5px;
            margin-left:8px;
        }

        #confirmationBox {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  z-index: 9999;
}

.confirmationContent {
  display: flex;
  align-items: center;
  justify-content: center;
}

.confirmationSymbol {
  font-size: 40px;
  color: green;
  margin-right: 10px;
}

.hidden {
  display: none;
}
.or{
    margin-left:5%;
}
.hr{
            background-color: grey; 
    border-color: grey;
    height: 2px;
        }
        #sbtn{
            /* height:25px; */
            margin-top:5px;
            /* padding-top:10px;
            padding-bottom:10px; */
            font-size:15px;
        }
        .link1{
            margin-left:35px;
            /* margin-top:7px; */
            
        }
        .link1 p{
            font-size:22px;
        }
        .success-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: red;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
        }
    
        /* .success-symbol {
            font-size: 50px;
            color: white;
            margin-right: 10px;
        } */
        .success-message {
    color: white; /* Set the text color to red */
    font-size: 16px; /* Adjust font size as needed */
    margin-left: 10px; /* Adjust margin as needed */
}
select{
    padding:8px;
    font-size:15px;
}
#pay option{
    font-size:15px;
    padding: 8px;
}
    </style>
</head>
<body>
   
<!-- <ul class="nav col-12 col-md-auto mb-2 justify-content-around mb-md-0">
        <li><a href="home.php" class="nav-link px-2 link-secondary fs-5 link1">Home</a></li>
</ul> -->

    </br>
    
    <h2 style="font-family: Georgia;font-size:35px;margin-left:12%;">Fill this form to confirm your order</h2>
    <div class="cont1">
   
<h2 style="font-family:cursive; margin-left:5%; font-size:28px; color:maroon;">Selected Food</h2>

<div class="or">
    <?php

if(isset($_GET['id'])){
    $id=$_GET['id'];
    $supp=$_GET['supp'];

    $sql= "select * from `Menu` where product_id=$id ";
    
    $res=mysqli_query($con,$sql);
    if($res){
        $count = mysqli_num_rows($res);
        if($count==1){
            $row=mysqli_fetch_assoc($res);
            
            $name=$row['product_name'];
            $price=$row['product_price'];
            $image=$row['product_image'];
            $desc=$row['product_desc'];

            echo '<div mb-5">
<div class="card box">
    <div><img src='.$image.' class="card-img-top" alt="product photo" style="height:200px; width:99%; object-fit:contain" ></div>
    <div class="card-body">
        <h2 class="card-title">'.$name.'</h2>
        
        <p style="font-size:20px;">'.$price.'/-</p>
        <p style="font-size:18px;">'.$desc.'</p>
               
        
        
    </div>
</div>
</div>';

        }
        
    }
    
}


?>


    <form action="" method="post" class="order">
    <br>
    <label style="font-size:20px;" for="quantity" id="qnt_label">Quantity</label>
        <input type="number" name="quantity" class="input-responsive" value="1" id="qnty_ip" required>
       
    <h2 style="font-family:cursive; font-size:28px; color:maroon;">Delivery Details</h2>
        <label for="cust_name">Full Name</label>
        <input type="text" name="cust_name" autocomplete="off">
        <label for="cust_contact">Phone Number</label>
        <input type="number" name="cust_contact" autocomplete="off">
        <label for="cust_email">Email</label>
        <input type="email" name="cust_email" autocomplete="off">
        <label for="cust_address">Address</label>
        <input name="cust_address" autocomplete="off">
        <label for="pay_mode">Payment Mode</label>
        <select name="pay" id="pay">
            <option value="cash">Cash On Delivery</option>
            <option value="online">Online</option>
        </select>
        <br><br>
        <input type="submit" value="Proceed Order" name="submit" id="sbtn">
        <div id="confirmationBox" class="hidden">
  <div class="confirmationContent">
    <span class="confirmationSymbol">&#10004;</span>
    <p>Order Placed Succesfully!!</p>
  </div>
</div>

    </form>

    <?php
    // date_default_timezone_set('Asia/Calcutta');
    // if(isset($_POST['submit'])){
    //     $food=$name;
    //     $price=$price;
    //     $supp=$supp;
        // $food=$_POST['food'];
        // $price=$_POST['price'];
        // $quantity=$_POST['quantity'];
        // $quantity = intval($quantit);
        // $total=$price*$quantity;
        // $dateTime=date("Y-m-d H:i:s A");
        
        // echo date("Y-m-d H:i:s A");
        
//         $mode=$_POST['pay'];
//         $status="Ordered";
//         $cust_name=$_POST['cust_name'];
//         $cust_contact=$_POST['cust_contact'];
//         $cust_email=$_POST['cust_email'];
//         $cust_address=$_POST['cust_address'];

//        if($cust_name=='' || $cust_contact=='' || $cust_email=='' || $cust_address==''){
//         echo '
//           <div class="success-container" id="success-container">
              
//               <div class="success-message">Fill the form details Completely</div>
//           </div>
//       ';
//        }
  
  
// else{
    
// if ($mode == "cash") {
   

    
        // If successful, set JavaScript variable
        // echo "<script> var orderSuccess = true; </script>";
        // $sql77="select 'avail_q' from `menu` where product_name='$food'";
        // $res77=mysqli_query($con,$sql77);
        // if($res77){
            // $row=$res77->fetch_assoc();
            // $q2=$row['avail_q']-$quantity;
            // $sql55="insert into `menu` (avail_q) values ($q2) where product_name='$food'";
            // $res55=mysqli_query($con,$sql55);

        //     $row = $res77->fetch_assoc();
        // $availQuantity = $row['avail_q'];
        // $newQuantity = intval($availQuantity) - intval($quantity);
        
        // Update the quantity in the database
    //     $sqlUpdate = "UPDATE `menu` SET avail_q=$newQuantity WHERE product_name='$food'";
    //     $resUpdate = mysqli_query($con, $sqlUpdate);
    //     $sql3 = "insert into `orders` (food,price,quantity,total,dateTime,mode,status,cust_name,cust_contact,cust_email,cust_address,product_supplier,username,email) values('$food','$price','$quantity','$total','$dateTime','$mode','$status','$cust_name','$cust_contact','$cust_email','$cust_address','$supp','$un','$email')";
    //     $res3 = mysqli_query($con, $sql3);
    // }
    //  else {
        // If failed, set JavaScript variable
        // echo "<script> var orderSuccess = false; </script>";
        // $_SESSION['order'] = "<div class='error'>Failed to Order!!</div>";
        // header('location:home.php');
        // exit(); // Ensure that code execution stops after redirection
//     }
// }


//     else{
//         $sql3="insert into `orders` (food,price,quantity,total,dateTime,mode,cust_name,cust_contact,cust_email,cust_address,product_supplier,username,email) values('$food','$price','$quantity','$total','$dateTime','$mode','$cust_name','$cust_contact','$cust_email','$cust_address','$supp','$un','$email')";
//         $res3=mysqli_query($con,$sql3);
//         if ($res3) {
            // If successful, set JavaScript variable
            // echo "<script> var orderSuccess = true; </script>";
            // $sql77="select 'avail_q' from `menu` where product_name='$food'";
            // $res77=mysqli_query($con,$sql77);
            // if($res77){
                // $row=$res77->fetch_assoc();
                // $q2=$row['avail_q']-$quantity;
                // $sql55="insert into `menu` (avail_q) values ($q2) where product_name='$food'";
                // $res55=mysqli_query($con,$sql55);
    
            //     $row = $res77->fetch_assoc();
            // $availQuantity = $row['avail_q'];
            // $newQuantity = intval($availQuantity) - intval($quantity);
            
            // Update the quantity in the database
        //     $sqlUpdate = "UPDATE `menu` SET avail_q=$newQuantity WHERE product_name='$food'";
        //     $resUpdate = mysqli_query($con, $sqlUpdate);
        //     }
        // }
        // if($res3){
        //     echo '<script>setTimeout(function(){window.location.href="pay.php?total='.$total.'&food='.$food.'";},1);</script>';
        // }
        // else{
        //     echo "error!!";
       // }
        // echo '<script>setTimeout(function(){window.location.href="pay.php?total='.$total.'";},1);</script>';
//     }
// }
//     }



// Start session and include database connection
// session_start();
// include 'connect.php';

if(isset($_POST['submit'])){
    // Retrieve session username
    // if(isset($_SESSION['username1'])){
    //     $un=$_SESSION['username1'];
    // } else {
    //     $un=$_SESSION['username2'];
    // }

    // Retrieve form data
    $food = $name;
    $price = $price;
    $quantity = $_POST['quantity'];
    $total = $price * $quantity;
    $dateTime = date("Y-m-d H:i:s A");
    $mode = $_POST['pay'];
    $status = "Ordered";
    $cust_name = $_POST['cust_name'];
    $cust_contact = $_POST['cust_contact'];
    $cust_email = $_POST['cust_email'];
    $cust_address = $_POST['cust_address'];

    // Query to retrieve available quantity
    $sql77 = "SELECT avail_q FROM `menu` WHERE product_name='$food'";
    $res77 = mysqli_query($con, $sql77);
    if($res77){
        $row = $res77->fetch_assoc();
        $availQuantity = $row['avail_q'];
        $newQuantity = intval($availQuantity) - intval($quantity);

        // Check if the remaining quantity is not negative
        if ($newQuantity >= 0) {
            // Update the database with the new quantity
            $sqlUpdate = "UPDATE `menu` SET avail_q=$newQuantity WHERE product_name='$food'";
            $resUpdate = mysqli_query($con, $sqlUpdate);

            // Check if the update was successful
            if ($resUpdate) {
                // Insert the order into the database
                if ($mode == "cash") {
                    $sqlInsert = "INSERT INTO `orders` (food, price, quantity, total, dateTime, mode, status, cust_name, cust_contact, cust_email, cust_address, product_supplier, username, email) VALUES ('$food', '$price', '$quantity', '$total', '$dateTime', '$mode', '$status', '$cust_name', '$cust_contact', '$cust_email', '$cust_address', '$supp', '$un', '$email')";
                    $resInsert = mysqli_query($con, $sqlInsert);
                    if($resInsert){
                        echo "<script> var orderSuccess = true; </script>";
                    } else {
                        echo "Error inserting order into database.";
                    }
                } else {
                    // Redirect to payment page after successful order for other payment modes
                    // header("Location: pay.php?total=$total&food=$food");
                    echo '<script>setTimeout(function(){window.location.href="pay.php?total='.$total.'&food='.$food.'";},1);</script>';
                    exit();
                }
            } else {
                echo "Failed to update quantity in the database.";
            }
        } else {
            echo "Ordered quantity exceeds available quantity.";
        }
    } else {
        echo "Error retrieving available quantity.";
    }
}


?>

    </div>

   
<script>


document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.getElementById('sbtn');
    const confirmationBox = document.getElementById('confirmationBox');

    if (typeof orderSuccess !== 'undefined' && orderSuccess) {
        confirmationBox.classList.remove('hidden');
        setTimeout(function() {
            confirmationBox.classList.add('hidden');
            window.location.href = 'home.php'; // Redirect to home.php
        }, 2000); // Hide after 2 seconds
    }
});

document.addEventListener("DOMContentLoaded", function() {
          
          var successContainer = document.getElementById("success-container");
          if (successContainer) {
              successContainer.style.display = "block";
              // Hide the success-container after 3 seconds
              setTimeout(function() {
                  successContainer.style.display = "none";
              }, 1000);
          }
      });

</script>
</div>
</body>
</html>