<?php include 'connect.php'; ?>


<!-- <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment Gateway</title>
<style>
    .cont1{
        margin-left:27%;
    }
  
  .input-container {
    position: relative;
    margin-bottom: 20px;
    
  }

  .input-container i {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #777;
  } -->

  <!-- .input-container input {
    padding-left: 30px; /* Adjust according to icon size */
    width: 60%;
    height: 40px;
    border: 1px solid black;
    border-radius: 5px;
    font-size: 16px;
  } -->
  <!-- input[type='submit']{
    width:100%;
  }  -->
  <!-- input[type="submit"]{
    padding-left: 30px; /* Adjust according to icon size */
    width: 63%;
    height: 40px;
    font-size:17px;
    
}
#confirmationBox {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  z-index: 9999;
} -->

<!-- .confirmationContent {
  display: flex;
  align-items: center;
  justify-content: center;
}

.confirmationSymbol {
  font-size: 40px;
  color: green;
  margin-right: 10px;
}

.hidden {
  display: none;
}
.btn{
    padding-left: 30px; -->
    <!-- /* Adjust according to icon size */
    width: 60%;
    height: 35px;
    
}
.payy{
  font-size:20px;
  font-family:serif;
}
</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>-->

  <?php 

    // if(isset($_GET['total']) && isset($_GET['food'])){
    //     $tot=$_GET['total'];
    //     $food=$_GET['food'];
    // }


?>
<!-- <div>
  <br>
<p style="text-align:center; font-family:Lora; font-size:28px">Welcome To Payment Gateway</p><br>

<div class="cont1">
<div class="input-container">
  <i class="fas fa-user"> -->
    <!-- <img src="eye-icon.svg" alt="email"> -->
    <!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
  <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z"/>
</svg>
  </i> 
  <input type="email" id="email" name="email" placeholder=" Email" autocomplete="off">
</div>

<div class="input-container">
  <i class="fas fa-lock"> -->
  <!-- <img src="eye-icon.svg" alt="email"> -->
  <!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-credit-card" viewBox="0 0 16 16">
  <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v1h14V4a1 1 0 0 0-1-1zm13 4H1v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1z"/>
  <path d="M2 10a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1z"/>
</svg> -->
  </i> <!-- Adjust the icon class here -->
  <!-- <input type="number" id="cardno" name="cardno" inputmode="numeric" pattern="[0-9]*" style="appearance: textfield;" placeholder=" 1234 1234 1234 1234" autocomplete="off">
</div>

<div class="input-container">
  <i class="fas fa-lock"> -->
  <!-- <img src="eye-icon.svg" alt="email"> -->
  <!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar3" viewBox="0 0 16 16">
  <path d="M14 0H2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2M1 3.857C1 3.384 1.448 3 2 3h12c.552 0 1 .384 1 .857v10.286c0 .473-.448.857-1 .857H2c-.552 0-1-.384-1-.857z"/>
  <path d="M6.5 7a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m-9 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m-9 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/>
</svg>
  </i>
  <input type="text" id="expDate" name="expDate" placeholder=" MM/YY" autocomplete="off">
  
</div>

<div class="input-container">
  <i class="fas fa-lock"> -->
  <!-- <img src="eye-icon.svg" alt="email"> -->
  <!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
  <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2m3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2M5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1"/>
</svg>
  </i>
  <input type="number" id="cvc" name="cvc" inputmode="numeric" pattern="[0-9]*" style="appearance: textfield;" placeholder=" CVC" autocomplete="off"> 

</div>

  

  <button id="submitBtn" class="btn btn-primary"><span class="payy">Pay <?php echo '₹ '.$tot.'.00'?></span></button>
<div id="confirmationBox" class="hidden">
  <div class="confirmationContent">
    <span class="confirmationSymbol">&#10004;</span>
    <p>Food Ordered Succesfully!!</p>
  </div>
</div> -->

<!-- </div>
</div>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script> -->

  
  





<!-- const submitBtn = document.getElementById('submitBtn');
const confirmationBox = document.getElementById('confirmationBox');

submitBtn.addEventListener('click', function() {
  confirmationBox.classList.remove('hidden');

  // Get the values of 'total' and 'food'
  var total = "<?=$tot?>"; // Assuming $total is already defined in your PHP code
  var food = "<?=$food?>";   // Assuming $food is already defined in your PHP code

  // Send an AJAX request to execute the PHP code
  var xhr = new XMLHttpRequest();
  xhr.open("GET", "process_order.php?food=" + encodeURIComponent(food) + "&total=" + encodeURIComponent(total), true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      // Code to handle the response, if needed
    }
  };
  xhr.send(); -->

  <!-- setTimeout(function() {
    confirmationBox.classList.add('hidden');
    window.location.href = 'home.php'; // Redirect to home.php after 2 seconds
  }, 2000); // Hide after 2 seconds
});



</script>
</body>
</html> -->


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment Gateway</title>
<style>
    .cont1{
        margin-left:27%;
    }
  
  .input-container {
    position: relative;
    margin-bottom: 20px;
    
  }

  .input-container i {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #777;
  }

  .input-container input {
    padding-left: 30px; /* Adjust according to icon size */
    width: 60%;
    height: 40px;
    border: 1px solid black;
    border-radius: 5px;
    font-size: 16px;
  }
  
  input[type="submit"]{
    padding-left: 30px; /* Adjust according to icon size */
    width: 63%;
    height: 40px;
    font-size:17px;
    
  }
  
  #confirmationBox {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    z-index: 9999;
  }

  .confirmationContent {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .confirmationSymbol {
    font-size: 40px;
    color: green;
    margin-right: 10px;
  }

  .hidden {
    display: none;
  }

  .btn{
    padding-left: 30px;
    width: 60%;
    height: 35px;
  }

  .payy{
    font-size:20px;
    font-family:serif;
  }

  .popup {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: rgba(255, 0, 0, 0.7);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    z-index: 9999;
    color: #fff;
  }
</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

<?php
if(isset($_GET['total']) && isset($_GET['food'])){
    $tot=$_GET['total'];
    $food=$_GET['food'];
}
?>

<div>
  <br>
  <p style="text-align:center; font-family:Lora; font-size:28px">Welcome To Payment Gateway</p><br>

  <div class="cont1">
    <div class="input-container">
      <i class="fas fa-user">
      <!-- <img src="eye-icon.svg" alt="email">  -->
   <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
  <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z"/>
</svg>
      </i> 
      <input type="email" id="email" name="email" placeholder=" Email" autocomplete="off">
    </div>

    <div class="input-container">
      <i class="fas fa-lock">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-credit-card" viewBox="0 0 16 16">
  <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v1h14V4a1 1 0 0 0-1-1zm13 4H1v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1z"/>
  <path d="M2 10a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1z"/>
</svg>
      </i> 
      <input type="number" id="cardno" name="cardno" inputmode="numeric" pattern="[0-9]*" style="appearance: textfield;" placeholder=" 1234 1234 1234 1234" autocomplete="off">
    </div>

    <div class="input-container">
      <i class="fas fa-lock">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar3" viewBox="0 0 16 16">
  <path d="M14 0H2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2M1 3.857C1 3.384 1.448 3 2 3h12c.552 0 1 .384 1 .857v10.286c0 .473-.448.857-1 .857H2c-.552 0-1-.384-1-.857z"/>
  <path d="M6.5 7a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m-9 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m-9 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2m3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/>
</svg>
      </i>
      <input type="text" id="expDate" name="expDate" placeholder=" MM/YY" autocomplete="off">
    </div>

    <div class="input-container">
      <i class="fas fa-lock">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
  <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2m3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2M5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1"/>
</svg>
      </i>
      <input type="number" id="cvc" name="cvc" inputmode="numeric" pattern="[0-9]*" style="appearance: textfield;" placeholder=" CVC" autocomplete="off"> 
    </div>

    <button id="submitBtn" class="btn btn-primary"><span class="payy">Pay <?php echo '₹ '.$tot.'.00'?></span></button>

    <div id="confirmationBox" class="hidden">
      <div class="confirmationContent">
        <span class="confirmationSymbol">&#10004;</span>
        <p>Food Ordered Successfully!!</p>
      </div>
    </div>

    <div id="popup" class="popup hidden">
      Fill the details completely.
      <br>Try again
    </div>
  </div>
</div>

<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script>
const submitBtn = document.getElementById('submitBtn');
const confirmationBox = document.getElementById('confirmationBox');
const popup = document.getElementById('popup');

submitBtn.addEventListener('click', function() {
  // Check if any field is empty
  const email = document.getElementById('email').value;
  const cardno = document.getElementById('cardno').value;
  const expDate = document.getElementById('expDate').value;
  const cvc = document.getElementById('cvc').value;

  if (email == '' || cardno == '' || expDate == '' || cvc == '') {
    popup.classList.remove('hidden');
    setTimeout(function() {
      popup.classList.add('hidden');
      window.location.href = 'home.php'; 
    }, 2000);
   
    return;
  }

  confirmationBox.classList.remove('hidden');

  // Get the values of 'total' and 'food'
  var total = "<?=$tot?>";
  var food = "<?=$food?>";

  // Send an AJAX request to execute the PHP code
  var xhr = new XMLHttpRequest();
  xhr.open("GET", "process_order.php?food=" + encodeURIComponent(food) + "&total=" + encodeURIComponent(total), true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      // Code to handle the response, if needed
    }
  };
  xhr.send();

  setTimeout(function() {
    confirmationBox.classList.add('hidden');
    window.location.href = 'home.php'; // Redirect to home.php after 2 seconds
  }, 2000); // Hide after 2 seconds
});
</script>
</body>
</html>

