<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
     include 'connect.php';

    session_start();
    $admin = $_SESSION['AdminID'];

     $product_name=$_POST['name'];
     $product_desc=$_POST['desc'];
     $product_price=$_POST['price'];
     $product_image=$_POST['image'];
     $product_category=$_POST['cat'];

    if(empty($product_name)||empty($product_desc)||empty($product_price)||empty($product_image)){
        echo '<script>alert("Error:Something Went wrong");</script>';
        echo '<script>setTimeout(function(){window.location.href="Adminpage.php";},500);</script>';
        exit("error");
    }

     $sql="insert into `Menu` (product_name,product_desc,product_price,product_image,product_supplier,product_category) values('$product_name','$product_desc','$product_price','$product_image','$admin','$product_category')";

     $result = mysqli_query($con,$sql);

     if($result){
        echo '<script>window.location.href="Adminpage.php?added=true";</script>';
        // header('location:Adminpage.php');
    }
    else{
        echo '<script>alert("Error:Something Went wrong");</script>';
        echo '<script>setTimeout(function(){window.location.href="Adminpage.php";},500);</script>';
    }
  
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
         *{
    box-sizing: border-box;   
    padding: 0; 
    /* background-color:#DFD3E3;   */
}
.container{
    margin-top: 10px;
    align-items: center;
    max-width: 600px;
    margin: auto;
    width: 90%;
    /* background-color:#D3D3D3;  */
    background-color:beige;
    border-radius: 10px;
    margin-bottom: 10px; 
}
label,input{
    display: block;
    margin-top: 5px;
    min-width: 100%;   
}
form{   
    max-width: 500px;
    width: 90%;
    margin: auto;
    margin-top: 2rem;
    margin-bottom: 5rem; 
    /* background-color:#D3D3D3;    */
    background-color:beige;
}
input{
    min-width: 100%;
    min-height: 5vh;
    border: 1px solid black;
    padding: 0.5rem;
    border-radius: 5px;
    height: 1rem;
}
label{
    font-weight: bolder;
    margin-top: 0.6rem;
}
 

.bttn{
    max-width: 300px;
    width: 100px;
    align-items: center;
    background-color: rgb(197, 120, 54);
    color: white;
    font-weight: bold;
    border-radius: 5px;
    padding: 5px;
    align-self: center;
    font-weight: bold;
}
.file-input-wrapper{
    position:relative;
    overflow:hidden;
    display:inline-block;
    border:1px solid #ccc;
    border-radius:4px;
    padding:6px 12px;
    cursor:pointer;
    width:150px;
}
.file-input-wrapper input[type=file]{
    position : absolute;
    font-size:100px;
    opacity: 0;
    right:0;
    top:0;
    cursor:pointer;
}
.file-path{
    margin-left:4px;
    width:250px;
    box-sizing:border-box;
}

select{
    width:500px;
}
.lst{
    width:100%;
    max-width:600px;
}
.btn{
    /* background-color: rgb(162, 89, 26); */
    /* color: white; */
    font-weight: bold;
    background-color:grey; 
    color:white;
    
}
.btn:hover{
    background-color:grey; 
    border:1px solid black;
    color:white;
}
input[type="submit"]{
            height:35px;
        }
        .link1{
            margin-left:35px;
            margin-top:7px;
            
        }
        .link1 p{
            font-size:22px;
        }
    </style>
</head>
<body>
<ul class="nav col-12 col-md-auto mb-2 justify-content-left mb-md-0">
        <li><a href="Adminpage.php" class="nav-link px-2 link-secondary fs-5 link1"><p>Back</p></a></li> 
</ul>
    <div class="container mt-1">
        <h2 style="text-align:center;">Add Product</h2>
        <form action="addMenu.php" method="POST" id="addMenu">

        <label for="name">Product name :</label>
        <input type="text" name="name" id="name" autocomplete="off">
        <label for="desc">Product desc :</label>
        <input type="text" name="desc" id="desc" autocomplete="off">
        <label for="dropdown" class="dropdown ">Product category :</label>
        <select name="cat" id="dropdown" class="lst">
            <option value="Breakfast">Breakfast</option>
            <option value="Homemade">Homemade</option>
            <option value="Main Course">Main Course</option>
            <option value="Snacks">Snacks</option>
            <option value="Thali">Thali</option>
            <option value="Desserts and ColdDrinks">Desserts and Cold drinks</option>
            <!-- <option value="Non-Veg">Non-Veg</option> -->
        </select>
        <label for="price">Product price :</label>
        <input type="number" name="price" id="price" autocomplete="off">
        <label for="price">Available Quantity:</label>
        <input type="number" name="q" id="q" autocomplete="off">



        <label for="image"> Select Product image :</label>
        <div class="file-input-wrapper">
        <input type="file" id="imageInput" name="image" accept="image/*">
        <span class="btn">Browse</span>
        </div>
        <input type="text" id="imagePath" class="file-path" readonly>


        <input type="submit" value="Add Product" name="submit" class="btn" id="submitBtn">
        </form>
    </div>


    <script>
       

        document.getElementById('imageInput').addEventListener('change',function(){
            const file = this.files[0];
            if (file){
                const fileName = file.name;
                document.getElementById('imagePath').value=fileName;
            }
        });

   

    </script>
</body>
</html>