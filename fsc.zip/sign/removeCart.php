<?php include 'connect.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remove From Cart</title>
</head>
<style>
   
</style>
<body>
    
<?php

   




// Check if the 'id' and 'un' parameters are set
if(isset($_GET['id']) && isset($_GET['un'])) {
    // Sanitize the input
    // $id = mysqli_real_escape_string($con, $_GET['id']);
    // $uname = mysqli_real_escape_string($con, $_GET['un']);
    // if(isset($_GET['deleteid'])){
        $id=$_GET['id'];
        $uname=$_GET['un'];
    // Query to delete the item from the cart
    $sql = "DELETE FROM cart WHERE product_id='$id' AND cust_name='$uname'";
    
    // Execute the query
    $result = mysqli_query($con, $sql);

    // Check if the query was successful
    if($result) {
        // Redirect back to cart.php with a query parameter
        header("Location: cart.php?item_deleted=true");
        exit();
        
    } else {
        // Handle error if the query fails
        echo "Error: " . mysqli_error($con);
    }
} else {
    // Handle case when 'id' and 'un' parameters are not set
    echo "Invalid request";
}
?>



</body>
</html>



